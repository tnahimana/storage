@extends('../layout/' . $layout)

@section('title')
    Update Shortcode | Electrix Vending
@endsection

@section('active-shortcode')
    side-menu--active
@endsection

@section('navigation')
    Update Shortcode
@endsection

@section('navigation-url')
    {{ $update->id }}/edit
@endsection

@section('subcontent')
    @livewire('shortcode.shortcode-update',[ 'update' => $update ])
@endsection