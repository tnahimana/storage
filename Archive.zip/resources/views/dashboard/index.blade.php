@extends('../layout/' . $layout)

@section('title')
    Dashboard
@endsection

@section('active-dashboard')
    side-menu--active
@endsection

@section('navigation')
    Dashboard
@endsection

@section('navigation-url')
    dashboard
@endsection

@section('subcontent')
    @livewire('dashboard.dashboard')
@endsection