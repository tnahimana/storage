<div class="content" id="centered">
    <x-loading />
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
            <form action="POST" wire:submit.prevent="save">
                <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                    <div class="intro-y flex items-center mt-6 border-b border-gray-200 dark:border-dark-5 pb-4">
                        <h2 class="text-lg font-medium mr-auto mt-4 ml-6">Register Admin</h2>
                    </div>

                    <div class="intro-y box mt-5">
                    
                        <div id="inline-form" class="p-5">

                            <div class="preview mr-5 ml-5">
                                <div class="flex flex-wrap -mx-3 mb-2">
                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-1" class="form-label">First Name</label>
                                            <input id="input-state-1" wire:model="firstname" type="text" class="form-control @error('firstname') border-theme-6 @elseif($firstname != "") border-theme-9 @enderror" placeholder="Firstname...">
                                            @error('firstname')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-2" class="form-label">Middle Name</label>
                                            <input id="input-state-2" wire:model="middlename" type="text" class="form-control @error('middlename') border-theme-6 @elseif($middlename != "") border-theme-9 @enderror" placeholder="Middlename...">
                                            @error('middlename')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div>
                                            <label for="input-state-3" class="form-label">Last Name</label>
                                            <input id="input-state-3" wire:model="lastname" type="text" class="form-control @error('lastname') border-theme-6 @elseif($lastname != "") border-theme-9 @enderror" placeholder="Lastname...">
                                            @error('lastname')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                </div>

                                <div class="flex flex-wrap -mx-3 mb-2">

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-1" class="form-label">Email</label>
                                            <input id="input-state-1" wire:model="email" type="email" class="form-control @error('email') border-theme-6 @elseif($email != "") border-theme-9 @enderror" placeholder="Email...">
                                            @error('email')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-2" class="form-label">Phone</label>
                                            <input id="input-state-2" wire:model="phone" type="text" class="form-control @error('phone') border-theme-6 @elseif($phone != "") border-theme-9 @enderror" placeholder="Phone..." maxlength="10">
                                            @error('phone')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div>
                                            <label for="input-state-3" class="form-label">Gender</label>
                                            <select id="input-state-3" wire:model="gender" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('gender') border-theme-6 @elseif($gender != "") border-theme-9 @enderror"
                                            >
                                                <option value="" selected>-- Select Gender --</option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select>
                                            @error('gender')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="flex flex-wrap -mx-3 mb-2">

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div>
                                            <label for="input-state-3" class="form-label">Document Type</label>
                                            <select id="input-state-3" wire:model="document_type" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('document_type') border-theme-6 @elseif($document_type != "") border-theme-9 @enderror"
                                            >
                                                <option value="" selected>-- Select Document Type --</option>
                                                @foreach($document as $item)
                                                    <option value="{{ $item->id }}">{{ $item->document_type }}</option>
                                                @endforeach
                                                
                                            </select>
                                            @error('document_type')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-1" class="form-label">@if($document_type == null)Document @elseif($document_type == 1) NID @else Passport @endif Number</label>
                                            <input id="input-state-1" wire:model="document_number" type="text" class="form-control @error('document_number') border-theme-6 @elseif($document_number != "") border-theme-9 @enderror" placeholder="@if($document_type == null)Document @elseif($document_type == 1) NID @else Passport @endif number..." @if($document_type == null) disabled @endif maxlength="16">
                                            @error('document_number')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div>
                                            <label for="input-state-3" class="form-label">Province</label>
                                            <select id="input-state-3" wire:model="province" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('province') border-theme-6 @elseif($province != "") border-theme-9 @enderror"
                                            >
                                                <option value="" selected>-- Select Province --</option>
                                                @foreach($provinces as $item)
                                                    <option value="{{ $item->id }}">{{ $item->province }}</option>
                                                @endforeach
                                                
                                            </select>
                                            @error('province')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                </div>

                                <div class="flex flex-wrap -mx-3 mb-2">

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div>
                                            <label for="input-state-3" class="form-label">District</label>
                                            <select id="input-state-3" wire:model="district" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('district') border-theme-6 @elseif($district != "") border-theme-9 @enderror"
                                            >
                                                <option value="" selected>-- Select District --</option>
                                                @foreach($districts as $item)
                                                    <option value="{{ $item->id }}">{{ $item->district }}</option>
                                                @endforeach
                                                
                                            </select>
                                            @error('district')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div>
                                            <label for="input-state-3" class="form-label">Sector</label>
                                            <select id="input-state-3" wire:model="sector" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('sector') border-theme-6 @elseif($sector != "") border-theme-9 @enderror"
                                            >
                                                <option value="" selected>-- Select Sector --</option>
                                                @foreach($sectors as $item)
                                                    <option value="{{ $item->id }}">{{ $item->sector }}</option>
                                                @endforeach
                                                
                                            </select>
                                            @error('sector')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div>
                                            <label for="input-state-3" class="form-label">Cell</label>
                                            <select id="input-state-3" wire:model="cell" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('cell') border-theme-6 @elseif($cell != "") border-theme-9 @enderror"
                                            >
                                                <option value="" selected>-- Select Cell --</option>
                                                @foreach($cells as $item)
                                                    <option value="{{ $item->id }}">{{ $item->cell }}</option>
                                                @endforeach
                                                
                                            </select>
                                            @error('cell')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                </div>

                                <div class="flex flex-wrap -mx-3 mb-2">

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div>
                                            <label for="input-state-3" class="form-label">Village</label>
                                            <select id="input-state-3" wire:model="village" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('village') border-theme-6 @elseif($village != "") border-theme-9 @enderror"
                                            >
                                                <option value="" selected>-- Select Village --</option>
                                                @foreach($villages as $item)
                                                    <option value="{{ $item->id }}">{{ $item->village }}</option>
                                                @endforeach
                                                
                                            </select>
                                            @error('village')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-1" class="form-label">Password</label>
                                            <input id="input-state-1" wire:model="password" type="password" class="form-control @error('password') border-theme-6 @elseif($password != "") border-theme-9 @enderror" placeholder="password...">
                                            @error('password')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-1" class="form-label">Password Confirmation</label>
                                            <input id="input-state-1" wire:model="password_confirmation" type="password" class="form-control @error('password_confirmation') border-theme-6 @elseif($password_confirmation != "") border-theme-9 @enderror" placeholder="password_confirmation...">
                                            @error('password_confirmation')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                </div>

                            </div>

                            <div id="input-state"  class="p-5 flex flex-wrap items-end justify-end">         
                                    <button type="submit" style="background-color: rgb(17, 17, 134)" class="btn btn-primary pl-5 pr-5 mt-5 mr-2 mb-2"> Submit <div wire:loading.delay>ing... <i  data-color="white" class="fas fa-spinner fa-pulse w-4 h-4 ml-2"></i> </div> </button>
                            </div>
                            
                        </div>
                        
                    </div>
                    
                </div>
            </form>
        </div>

    </div>    
</div>