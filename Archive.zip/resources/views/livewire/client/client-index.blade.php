<div>
    <x-loading />
    <h2 class="intro-y text-lg font-medium mt-10">List Of Clients</h2>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
            <a href="/clients/create" class="btn btn-primary shadow-md mr-2">Add New Client</a>
            <select class="w-20 form-select box mt-3 sm:mt-0" wire:model="perPage">
                <option value="10">10</option>
                <option value="25">25</option>
                <option value="50">50</option>
                <option value="100">100</option>
                <option value="500">500</option>
            </select>
             <div class="flex mt-5 sm:mt-0 ml-2">
                {{-- <button id="tabulator-print" class="btn btn-outline-secondary w-1/2 sm:w-auto mr-2"> <i data-feather="printer" class="w-4 h-4 mr-2"></i> Print </button>
                <div class="dropdown w-1/2 sm:w-auto">
                    <button class="dropdown-toggle btn btn-outline-secondary w-full sm:w-auto" aria-expanded="false"> <i data-feather="file-text" class="w-4 h-4 mr-2"></i> Export <i data-feather="chevron-down" class="w-4 h-4 ml-auto sm:ml-2"></i> </button>
                    <div class="dropdown-menu w-40">
                        <div class="dropdown-menu__content box dark:bg-dark-1 p-2">
                            <a id="tabulator-export-csv" href="javascript:;" class="flex items-center block p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="file-text" class="w-4 h-4 mr-2"></i> Export CSV </a>
                            <a id="tabulator-export-json" href="javascript:;" class="flex items-center block p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="file-text" class="w-4 h-4 mr-2"></i> Export JSON </a>
                            <a id="tabulator-export-xlsx" href="javascript:;" class="flex items-center block p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="file-text" class="w-4 h-4 mr-2"></i> Export XLSX </a>
                            <a id="tabulator-export-html" href="javascript:;" class="flex items-center block p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="file-text" class="w-4 h-4 mr-2"></i> Export HTML </a>
                        </div>
                    </div>
                </div> --}}
            </div>
            <div class="hidden md:block mx-auto text-gray-600">
                
            </div>
            <div class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0">
                <div class="w-56 relative text-gray-700 dark:text-gray-300">
                    <input wire:model.debounce.100ms="search" type="text" class="form-control w-56 box pr-10 placeholder-theme-13" placeholder="Search...">
                    <i class="w-4 h-4 absolute my-auto inset-y-0 mr-3 right-0" data-feather="search"></i>
                </div>
            </div>
        </div>
        <!-- BEGIN: Data List -->
        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
            <table class="table table-report -mt-2">
                <thead>
                    <tr>
                        <th class="whitespace-nowrap">S/N</th>
                        <th class="whitespace-nowrap">FIRST NAME</th>
                        <th class="whitespace-nowrap">MIDDLE NAME</th>
                        <th class="whitespace-nowrap">LAST NAME</th>
                        <th class="whitespace-nowrap">EMAIL</th>
                        <th class="whitespace-nowrap">PHONE</th>
                        <th class="text-center whitespace-nowrap">ACTIONS</th>
                    </tr>
                </thead>
                <tbody>

                    @forelse($clients as $item)
                        
                        <tr class="intro-x">
                            <td class="w-20">
                                {{ $i++ }}
                            </td>
                            <td>
                                {{ $item->firstname }}
                            </td>
                            <td>
                                {{ $item->middlename }}
                            </td>
                            <td>
                                {{ $item->lastname }}
                            </td>
                            <td>
                                {{ $item->email }}
                            </td>
                             <td>
                                {{ $item->phone }}
                            </td>
                            <td class="table-report__action w-56">
                                <div class="flex justify-center items-center">
                                    <a class="flex items-center btn btn-rounded btn-primary-soft hover:text-gray-100 w-auto mr-3 -mt-1 h-6" href="/clients/{{ $item->id }}">
                                        <i class="w-4 h-3 mr-1 fas fa-eye" name="eye"></i>
                                         Show
                                    </a>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr class="intro-x">
                            <td colspan="7" class="text-center">
                                No record found!
                            </td>
                        </tr>
                    @endforelse
                    </tbody>
            </table>
        </div>
        <!-- END: Data List -->
        <!-- BEGIN: Pagination -->
        <div class="intro-y col-span-12 flex flex-wrap sm:flex-row sm:flex-nowrap items-center">
            <ul class="pagination">
                
            </ul>
            <div class="pl-5 pr-5 pt-1 pb-1 box mt-3 sm:mt-0">
                <ul class="pagination">
                 {!! $clients->links() !!}
                </ul>
            </div>
            
        </div>
        <!-- END: Pagination -->
    </div>
</div>
