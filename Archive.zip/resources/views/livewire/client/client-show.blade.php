@if($showClient)
<div class="content">
    <x-loading />
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
            <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                <div class="intro-y flex items-center mt-6 border-b border-gray-200 dark:border-dark-5 pb-4">
                    <h2 class="text-lg font-medium mr-auto mt-4 ml-6">Client Information</h2>
                    <div class="mt-3 hidden md:block mr-6">
                        @if(auth()->user()->role->name != 'client')
                            <div class="preview">
                                @if(auth()->user()->role->name == 'super_admin' || auth()->user()->role->name == 'admin')
                                    @if($client->account_status == 'Inactive')
                                    <button wire:click="activate({{ $client->id }})" type="button" style="background-color: green; hover:border: 1px solid white" class="btn btn-rounded-success w-24 mr-1 mb-2">Activate</button>
                                    @elseif($client->account_status == 'Active')
                                    <button wire:click="suspend({{ $client->id }})" type="button" style="background-color: red; hover:border: 1px solid white" class="btn btn-rounded-danger w-24 mr-1 mb-2">Suspend</button>
                                    @endif
                                @endif
                                <button wire:click="addRegMeter({{ $client->id }})" type="button" style="background-color: rgb(17, 17, 134)" class="btn btn-rounded-primary w-50 mr-1 mb-2 ml-2"><i class="fas fa-plus mr-2 w-4 h-3"></i>  Reg Meter</button>
                                <button wire:click="addWasacMeter({{ $client->id }})" type="button" style="background-color: rgb(17, 17, 134)" class="btn btn-rounded-primary w-50 mr-1 mb-2 ml-2"><i class="fas fa-plus mr-2 w-4 h-3"></i>  Wasac Meter</button>
                            </div>
                        @endif
                    </div>
                </div>

                <div class="intro-y box mt-5">
                
                    <div id="inline-form" class="p-5">

                        <div class="preview sm:mr-5 sm:ml-5">
                            <div class="intro-y box sm:px-5 pt-5 mt-1">
                                <div class="flex flex-col lg:flex-row border-b border-gray-200 dark:border-dark-5 pb-5 -mx-5">
                                    <div class="flex flex-2 sm:px-5 items-center justify-center lg:justify-start">
                                        @if($showImage)
                                            <form action="POST" wire:submit.prevent="upload({{ $client->id }})">
                                                <div class="intro-y box -mt-1" style="border-top: 2px solid blue">

                                                    <div class="intro-y flex items-center border-b border-gray-200 dark:border-dark-5 pb-4">
                                                        <h2 class="text-sm font-medium mr-auto mt-4 ml-6">Update Profile</h2>
                                                    </div>

                                                    <div id="inline-form" class="p-5">

                                                            <div class="w-full md:w-full px-3 mb-0 md:mb-0">
                                                                <div class="w-full md:w-full" wire:loading> 
                                                                    <div class="alert alert-success-soft show flex items-center mb-2 w-full" role="alert" wire:target="image" wire:loading>
                                                                        <i class="fas fa-spinner w-6 h-3 mr-2"></i> Uploading...
                                                                    </div>
                                                                </div>
                                                                <div class="md:mr-2">
                                                                    @if(!$image)
                                                                    <input id="input-state-1" wire:model="image" type="file" class="form-control" placeholder="image..." accept="image/*">
                                                                    @elseif($image)
                                                                    <div class="w-20 h-20 sm:w-24 sm:h-24 flex-none lg:w-32 lg:h-32 image-fit relative">
                                                                        <img alt="{{ $client->firstname }}"  class="rounded-full" src="{{ $image->temporaryUrl() }}">
                                                                        @if(!$showImage)
                                                                            @if(auth()->user()->id == $client->id)
                                                                                <div wire:click="addImage" class="absolute mb-1 mr-1 flex items-center justify-center bottom-0 right-0 bg-theme-1 rounded-full p-2"> <i class="w-4 h-3 text-white fas fa-camera"></i> </div>
                                                                            @endif
                                                                        @endif
                                                                    </div>
                                                                    @endif
                                                                    @error('image')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                </div>
                                                            </div>

                                                        <div id="input-state"  class="p-3 flex flex-wrap items-end justify-end">
                                                            <button wire:click="resetImage" style="background-color: red" type="button" class="btn btn-rounded-danger w-24 mt-3 pr-4 pl-4 mr-2">Reset</button>
                                                            <button type="submit" style="background-color: rgb(17, 17, 134)" class="btn btn-rounded-primary w-24 mt-3 pr-4 pl-4">upload <div wire:loading.delay>ing... <i class="fas fa-spinner fa-spin"></i></div></button>
                                                        </div>
                                                        
                                                    </div>
                                                        
                                                </div>
                                            </form>
                                        @else
                                            <div class="w-20 h-20 sm:w-24 sm:h-24 flex-none lg:w-32 lg:h-32 image-fit relative">
                                                <img alt="{{ $client->firstname }}" class="rounded-full" src="@if($client->image_id != null) {{ asset($client->image->img_url) }} @else {{ asset('dist/images/profile-4.jpg') }} @endif">
                                                @if(!$showImage)
                                                    @if(auth()->user()->id == $client->id)
                                                        <div wire:click="addImage" class="absolute mb-1 mr-1 flex items-center justify-center bottom-0 right-0 bg-theme-1 rounded-full p-2"> <i class="w-4 h-3 text-white fas fa-camera"></i> </div>
                                                    @endif
                                                @endif
                                            </div>
                                            <div class="ml-5">
                                                <div class="w-24 sm:w-40 truncate sm:whitespace-normal font-medium text-lg">{{ $client->firstname }}</div>
                                                <div class="text-gray-600 capitalize font-medium">{{ $client->role->name }}</div>
                                            </div>
                                        @endif
                                    </div>
                                    @if($personalInfo)
                                        <div id="height"  class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Personal Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="truncate sm:whitespace-normal flex items-center"> 
                                                    <i class="fas fa-user h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">First Name:</strong>{{ $client->firstname }}</span>
                                                </div>
                                                @if($client->middlename)
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-user h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Middle Name:</strong>{{ $client->middlename }}</span>
                                                </div>
                                                @endif
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-user h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Last Name:</strong>{{ $client->lastname }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-id-card h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">{{ $client->document->document_type . " "}}Number:</strong>{{ $client->document_number }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-venus-mars h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Gender:</strong>{{ $client->gender }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    @elseif($contactInfo)
                                        <div id="height" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Contact Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="truncate sm:whitespace-normal flex items-center"> 
                                                    <i class="fas fa-envelope h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Email:</strong>{{ $client->email }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-phone-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Phone:</strong>{{ $client->phone }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    @elseif($addressInfo)
                                        <div id="height" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0 mb-2">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Address Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="truncate sm:whitespace-normal flex mt-2 mb-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Office Address:</strong>{{ $client->address->office_address }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Province:</strong>{{ $client->address->province->province }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">District:</strong>{{ $client->address->district->district }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Sector:</strong>{{ $client->address->sector->sector }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Cell:</strong>{{ $client->address->cell->cell }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Village:</strong>{{ $client->address->village->village }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    @elseif($regMeter)
                                        <div id="" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0" style="width: 100%">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Reg Main Meter Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="-mt-6">
                                                    <div class="grid grid-cols-12 gap-6 mt-5">
                                                        {{-- Pagination --}}
                                                        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
                                                            <select class="w-20 form-select box mt-3 sm:mt-0" wire:model="perPage">
                                                                <option value="5">5</option>
                                                                <option value="10">10</option>
                                                                <option value="25">25</option>
                                                                <option value="50">50</option>
                                                            </select>
                                                            <div class="hidden md:block mx-auto text-gray-600">
                                                
                                                            </div>
                                                            <div class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0">
                                                                <div class="w-56 relative text-gray-700 dark:text-gray-300">
                                                                    <input wire:model.debounce.100ms="search" type="text" class="form-control w-56 box pr-10 placeholder-theme-13" placeholder="Search...">
                                                                    <i class="w-4 h-4 absolute my-auto inset-y-0 mr-3 right-0" data-feather="search"></i>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
                                                            <table class="table table-report -mt-2 table-responsive w-full" style="width: 100%">
                                                                <thead>
                                                                    <tr>
                                                                        <th class="whitespace-nowrap">S/N</th>
                                                                        <th class="whitespace-nowrap">Reg Meter N<sup>0</sup></th>
                                                                        <th class="text-center whitespace-nowrap">ACTIONS</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>

                                                                    @forelse($meters as $item)
                                                                        
                                                                        <tr class="intro-x">
                                                                            <td>
                                                                                {{ $i++ }}
                                                                            </td>
                                                                            <td>
                                                                                <div class="btn-rounded pl-1 pr-1 btn-primary-soft text-center" wire:click="ShowLocation({{ $item->id }})">{{ $item->reg_meter_number }}</div>
                                                                            </td>
                                                                            <td class="table-report__action w-auto">
                                                                                <div class="flex justify-center items-center">
                                                                                    @if(auth()->user()->role->name == 'agent')
                                                                                        @if($item->meter_status == 'Active')
                                                                                        <span class="rounded-lg pr-2 pl-2 btn-success-soft mr-6">{{ $item->meter_status }}</span>
                                                                                        @else
                                                                                        <span class="rounded-lg pr-2 pl-2  btn-danger-soft mr-6">{{ $item->meter_status }}</span>
                                                                                        @endif
                                                                                    @endif
                                                                                    <button type="button" class="flex items-center btn btn-rounded btn-primary-soft  w-25 mr-3 -mt-1 h-6" wire:click="ShowElectrixReg({{ $item->id }},{{ $client->id }})">
                                                                                        <i class="far fa-eye w-3 h-4 mr-1 mt-1"></i>
                                                                                        Meters
                                                                                    </button>
                                                                                    @if(auth()->user()->role->name == 'super_admin' || auth()->user()->role->name == 'admin')
                                                                                        @if($item->meter_status == 'Active')
                                                                                        <button type="button" class="flex items-center btn btn-rounded btn-danger-soft w-24 -mt-1 h-6" wire:click="deactivateMeter({{ $item->id }},{{ $client->id }})">
                                                                                            <i class="far fa-edit w-4 h-4 mr-1 mt-1"></i>
                                                                                            Deactivate
                                                                                        </button>
                                                                                        @else
                                                                                        <button type="button" class="flex items-center btn btn-rounded btn-success-soft w-24 -mt-1 h-6" wire:click="activateMeter({{ $item->id }},{{ $client->id }})">
                                                                                            <i class="far fa-edit w-3 h-4 mr-1 mt-1"></i>
                                                                                            Activate
                                                                                        </button>
                                                                                        @endif
                                                                                    @endif
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    @empty
                                                                        <tr class="intro-x">
                                                                            <td colspan="3" class="text-center">
                                                                                No record found!
                                                                            </td>
                                                                        </tr>
                                                                    @endforelse
                                                                    </tbody>
                                                            </table>
                                                             <!-- BEGIN: Pagination -->
                                                            <div class="intro-y col-span-12 flex flex-wrap sm:flex-row sm:flex-nowrap items-center" style="margin-right: -4%">
                                                                <ul class="pagination">
                                                                    
                                                                </ul>
                                                                <div class="pl-5 pr-5 pt-1 pb-1 box mt-3 sm:mt-0">
                                                                    <ul class="pagination">
                                                                    {!! $meters->links() !!}
                                                                    </ul>
                                                                </div>
                                                                
                                                            </div>
                                                            <!-- END: Pagination -->
                                                        </div>
                                                        <!-- END: Data List -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @elseif($wasacMeter)
                                        <div id="" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0" style="width: 100%">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Wasac Main Meter Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="-mt-6">
                                                    <div class="grid grid-cols-12 gap-6 mt-5">
                                                        {{-- Pagination --}}
                                                        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
                                                            <select class="w-20 form-select box mt-3 sm:mt-0" wire:model="perPage">
                                                                <option value="5">5</option>
                                                                <option value="10">10</option>
                                                                <option value="25">25</option>
                                                                <option value="50">50</option>
                                                            </select>
                                                            <div class="hidden md:block mx-auto text-gray-600">
                                                
                                                            </div>
                                                            <div class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0">
                                                                <div class="w-56 relative text-gray-700 dark:text-gray-300">
                                                                    <input wire:model.debounce.100ms="search" type="text" class="form-control w-56 box pr-10 placeholder-theme-13" placeholder="Search...">
                                                                    <i class="w-4 h-4 absolute my-auto inset-y-0 mr-3 right-0" data-feather="search"></i>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
                                                            <table class="table table-report -mt-2 table-responsive w-full" style="width: 100%">
                                                                <thead>
                                                                    <tr>
                                                                        <th class="whitespace-nowrap">S/N</th>
                                                                        <th class="whitespace-nowrap">Wasac Meter N<sup>0</sup></th>
                                                                        <th class="text-center whitespace-nowrap">ACTIONS</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>

                                                                    @forelse($wasac_meters as $item)
                                                                        
                                                                        <tr class="intro-x">
                                                                            <td>
                                                                                {{ $i++ }}
                                                                            </td>
                                                                            <td>
                                                                                <div class="btn-rounded pl-1 pr-1 btn-primary-soft text-center" wire:click="ShowLocation({{ $item->id }})">{{ $item->wasac_meter_number }}</div>
                                                                            </td>
                                                                            <td class="table-report__action w-auto">
                                                                                <div class="flex justify-center items-center">
                                                                                    @if(auth()->user()->role->name == 'agent')
                                                                                        @if($item->meter_status == 'Active')
                                                                                        <span class="rounded-lg pr-2 pl-2 btn-success-soft mr-6">{{ $item->meter_status }}</span>
                                                                                        @else
                                                                                        <span class="rounded-lg pr-2 pl-2  btn-danger-soft mr-6">{{ $item->meter_status }}</span>
                                                                                        @endif
                                                                                    @endif
                                                                                    <button type="button" class="flex items-center btn btn-rounded btn-primary-soft  w-25 mr-3 -mt-1 h-6" wire:click="ShowElectrixWasac({{ $item->id }},{{ $client->id }})">
                                                                                        <i class="far fa-eye w-3 h-4 mr-1 mt-1"></i>
                                                                                        Meters
                                                                                    </button>
                                                                                    @if(auth()->user()->role->name == 'super_admin' || auth()->user()->role->name == 'admin')
                                                                                        @if($item->meter_status == 'Active')
                                                                                        <button type="button" class="flex items-center btn btn-rounded btn-danger-soft w-24 -mt-1 h-6" wire:click="deactivateMeter({{ $item->id }},{{ $client->id }})">
                                                                                            <i class="far fa-edit w-4 h-4 mr-1 mt-1"></i>
                                                                                            Deactivate
                                                                                        </button>
                                                                                        @else
                                                                                        <button type="button" class="flex items-center btn btn-rounded btn-success-soft w-24 -mt-1 h-6" wire:click="activateMeter({{ $item->id }},{{ $client->id }})">
                                                                                            <i class="far fa-edit w-3 h-4 mr-1 mt-1"></i>
                                                                                            Activate
                                                                                        </button>
                                                                                        @endif
                                                                                    @endif
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    @empty
                                                                        <tr class="intro-x">
                                                                            <td colspan="3" class="text-center">
                                                                                No record found!
                                                                            </td>
                                                                        </tr>
                                                                    @endforelse
                                                                    </tbody>
                                                            </table>
                                                             <!-- BEGIN: Pagination -->
                                                            <div class="intro-y col-span-12 flex flex-wrap sm:flex-row sm:flex-nowrap items-center" style="margin-right: -4%">
                                                                <ul class="pagination">
                                                                    
                                                                </ul>
                                                                <div class="pl-5 pr-5 pt-1 pb-1 box mt-3 sm:mt-0">
                                                                    <ul class="pagination">
                                                                    {!! $meters->links() !!}
                                                                    </ul>
                                                                </div>
                                                                
                                                            </div>
                                                            <!-- END: Pagination -->
                                                        </div>
                                                        <!-- END: Data List -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @elseif($showElectrix)
                                        <div id="" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Main Meter N<sup>o</sup>: 
                                               @if($mainMeter != null) <span wire:click="ShowLocation({{ $mainMeter->id }})"><span class="text-gray-700">@if($regSelected) {{ $mainMeter->reg_meter_number }} @elseif($wasacSelected) {{ $mainMeter->wasac_meter_number }} @endif</span></span> 
                                                <span wire:click="@if($regSelected) ShowElectrixReg({{ $mainMeter->id }}, {{ $mainMeter->client_id }}) @elseif($wasacSelected) ShowElectrixWasac({{ $mainMeter->id }}, {{ $mainMeter->client_id }}) @endif" class="flex justify-end items-end"><i class="fas fa-redo w-4 h-4 -mt-4 mr-2"></i></span> 
                                                @endif
                                            </div>
                                            @if(auth()->user()->role->name != 'client')
                                                <div class="flex flex-wrap justify-end items-end mt-2">
                                                    @if($mainMeter != null)<button wire:click="addElectrix({{ $mainMeter->id }}, @if($regSelected) 'REG' @elseif($wasacSelected) 'WASAC' @endif)" type="button" class="p-1 pr-2 pl-2 btn btn-rounded btn-primary-soft" style="border: 1px solid rgb(151, 151, 233)">ADD Electrix @if($regSelected) Energy @elseif($wasacSelected) Water @endif Meter</button> @endif
                                                </div>
                                            @endif
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4" style="width: 70%">
                                                <div class="-mt-6">
                                                    <div class="grid grid-cols-12 gap-6 mt-5">
                                                        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
                                                            @if(auth()->user()->role->name != 'agent')
                                                            <table class="table table-report -mt-2 table-responsive w-full" style="width: 120%">
                                                            @else
                                                            <table class="table table-report -mt-2 table-responsive w-full" style="width: 120%">
                                                            @endif
                                                                <thead>
                                                                    <tr>
                                                                        <th class="whitespace-nowrap">S/N</th>
                                                                        <th class="whitespace-nowrap">Electrix @if($regSelected) Energy @elseif($wasacSelected) Water @endif Meter N<sup>o</sup></th>
                                                                        <th class="text-center whitespace-nowrap">ACTIONS</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>

                                                                    @forelse($electrixMeter as $item)
                                                                        
                                                                        <tr class="intro-x">
                                                                            <td>
                                                                                {{ $i++ }}
                                                                            </td>
                                                                            <td>
                                                                                <span class="btn-rounded btn-primary-soft pr-1 pl-1" wire:click="ShowLocation({{ $mainMeter->id }})">{{ $item->electrix_meter_number }}</span>
                                                                            </td>
                                                                            <td class="table-report__action w-auto text-center" colspan="2">
                                                                                <div class="flex justify-center items-center">
                                                                                    @if($item->meter_status == 'Active')
                                                                                    <span class="rounded-lg pr-2 pl-2 btn-success-soft mr-4">{{ $item->meter_status }}</span>
                                                                                    @else
                                                                                    <span class="rounded-lg pr-2 pl-2  btn-danger-soft mr-4">{{ $item->meter_status }}</span>
                                                                                    @endif
                                                                                    @if(auth()->user()->role->name == 'super_admin' || auth()->user()->role->name == 'admin')
                                                                                        @if($item->meter_status == 'Active')
                                                                                        <button type="button" class="flex items-center btn btn-rounded btn-danger-soft w-24 mr-3 -mt-1 h-6" wire:click="electrixDeactivate({{ $item->id }},{{ $client->id }})">
                                                                                            <i class="far fa-edit w-3 h-4 mr-1 mt-1"></i>
                                                                                            Deactivate
                                                                                        </button>
                                                                                        @else
                                                                                        <button type="button" class="flex items-center btn btn-rounded btn-success-soft w-24 mr-3 -mt-1 h-6" wire:click="electrixActivate({{ $item->id }},{{ $client->id }})">
                                                                                            <i class="far fa-edit w-3 h-4 mr-1 mt-1"></i>
                                                                                            Activate
                                                                                        </button>
                                                                                    @endif
                                                                                    </div>
                                                                                </td>
                                                                            @endif
                                                                        </tr>
                                                                    @empty
                                                                        <tr class="intro-x">
                                                                            <td colspan="4" class="text-center">
                                                                                No record found!
                                                                            </td>
                                                                        </tr>
                                                                    @endforelse
                                                                    </tbody>
                                                            </table>
                                                        </div>
                                                        <!-- END: Data List -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @elseif($meterLocation)
                                        <div id="" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">
                                                <span>@if($regSelected) REG @elseif($wasacSelected) WASAC @endif Meter N<sup>o</sup>:</span>
                                                <span class="btn-primary-soft pr-2 pl-2 rounded-lg">@if($regSelected) {{ $meter->reg_meter_number }} @elseif($wasacSelected) {{ $meter->wasac_meter_number }} @endif</span>
                                                Location
                                            </div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="truncate sm:whitespace-normal flex items-center"> 
                                                    <i class="fa-solid fa-bolt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Meter Type:</strong>{{ $meter->meter_type }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex items-center mt-2"> 
                                                    <i class="fas fa-map-marked-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Land UPI:</strong>{{ $meter->land_upi }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex items-center mt-2"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Province:</strong>{{ $meter->province->province }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">District:</strong>{{ $meter->district->district }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Sector:</strong>{{ $meter->sector->sector }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Cell:</strong>{{ $meter->cell->cell }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Village:</strong>{{ $meter->village->village }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Street Address:</strong>{{ $meter->meter_street_address }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                                <div class="nav nav-tabs flex-col sm:flex-row justify-center lg:justify-start" role="tablist"> 
                                    <button wire:click="personalInfo" type="button" id="dashboard-tab" data-toggle="tab" data-target="#dashboard" class="py-4 sm:mr-8 @if($personalInfo) active @endif" role="tab" aria-controls="dashboard" aria-selected="true">Personal Info</button> 
                                    <button wire:click="contactInfo" type="button" id="account-and-profile-tab" data-toggle="tab" data-target="#account-and-profile" class="py-4 sm:mr-8 @if($contactInfo) active @endif" role="tab" aria-selected="false">Contact Info</button> 
                                    <button wire:click="addressInfo" type="button" id="activities-tab" data-toggle="tab" data-target="#activities" class="py-4 sm:mr-8 @if($addressInfo) active @endif" role="tab" aria-selected="false">Address Info</button> 
                                    <button wire:click="RegMeterInfo" type="button" id="activities-tab" data-toggle="tab" data-target="#activities" class="py-4 sm:mr-8 @if($regMeter || $regElectrixInfo) active @endif" role="tab" aria-selected="false">Reg Meters Info</button> 
                                    <button wire:click="WasacMeterInfo" type="button" id="activities-tab" data-toggle="tab" data-target="#activities" class="py-4 sm:mr-8 @if($wasacMeter || $wasacElectrixInfo) active @endif" role="tab" aria-selected="false">Wasac Meters Info</button> 
                                    @if($meterLocation)
                                    <button type="button"  class="py-4 sm:mr-8 @if($meterLocation) active @endif" role="tab" aria-selected="false">Meters Location</button> 
                                    @endif
                                    <div class="mt-3 flex justify-center" id="hide">
                                        <div class="preview">
                                            @if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin')
                                                @if($client->account_status == 'Inactive')
                                                <button wire:click="activate({{ $client->id }})" type="button" style="background-color: green; hover:border: 1px solid white" class="btn btn-rounded-success w-24 mr-1 mb-2">Activate</button>
                                                @elseif($client->account_status == 'Active')
                                                <button wire:click="suspend({{ $client->id }})" type="button" style="background-color: red; hover:border: 1px solid white" class="btn btn-rounded-danger w-24 mr-1 mb-2">Suspend</button>
                                                @endif
                                            @endif
                                            @if(auth()->user()->role->name != 'client')
                                                <button wire:click="addMeter({{ $client->id }})" type="button" style="background-color: rgb(17, 17, 134)" class="btn btn-rounded-primary w-54 mr-1 mb-2"><i class="fas fa-plus mr-2 w-4 h-3"></i> ADD Meter</button>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
        </div>
    </div>    
</div>
@elseif($addMeter)
    @include('client.add-meter');
@elseif($addElectrix)
    @include('client.add-meter-electrix');
@endif