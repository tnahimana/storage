
<div class="flex">
    <!-- BEGIN: Content -->
    <div class="content">
        <div class="container mx-auto mt-4">
            <div class="grid lg:grid-cols-2 gap-12">
                <div wire:click="clearTamper" class="flex justify-center p-6 text-6xl bg-green-200 border-2 border-gray-300 rounded-xl">
                    <i class="fa-solid fa-unlock-keyhole mr-12"></i><br>
                    <span class="text-base font-bold">Clear Tamper</span>
                </div>
                <div wire:click="clearCredit" class="flex justify-center p-6 text-6xl bg-green-200 border-2 border-gray-300 rounded-xl">
                    <i class="fa-solid fa-credit-card mr-12 mt-2"></i> <br>
                    <span class="text-base font-bold">Clear Credit</span>
                </div>
                {{-- <div wire:click="meterRecords" class="flex justify-center p-6 text-6xl bg-green-200 border-2 border-gray-300 rounded-xl">
                    <i class="fa-solid fa-stopwatch-20 mr-3 mt-2"></i>
                    <span class="text-base font-bold">Meter Records</span>
                </div>
                <div class="flex justify-center p-6 text-6xl bg-green-200 border-2 border-gray-300 rounded-xl">
                    <ion-icon class="-ml-5 mt-2" name="thermometer-outline"></ion-icon>
                    <span class="text-base font-bold">Meter Sales</span>
                </div> --}}
            </div>
        </div>
        <div class="container mx-auto mt-6">
            @if($form == true)
                <div class="content" id="centered">
                    <x-loading />
                    <div class="grid lg:grid-cols-8 gap-6 mt-3">
                        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
                            <form action="POST" wire:submit.prevent="save">
                                <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                                    <div class="intro-y flex items-center mt-6 border-b border-gray-200 dark:border-dark-5 pb-4">
                                        <h2 class="text-lg font-medium mr-auto mt-4 ml-6">
                                            @if($this->tamper == true) Clear Tamper @elseif($credit == true) Clear Credit @endif
                                        </h2>
                                    </div>

                                    <div class="intro-y box mt-5">
                                    
                                        <div id="inline-form" class="p-5">

                                            <div class="preview mr-5 ml-5">
                                                <div class="flex flex-wrap -mx-3 mb-2">
                                                    <div class="w-full md:w-full px-3 mb-6 md:mb-0">
                                                        <div class="md:mr-2">
                                                            <input id="input-state-1" wire:model="meter_number" type="text" class="form-control @error('meter_number') border-theme-6 @elseif($meter_number != "") border-theme-9 @enderror" placeholder="Electrix Meter Number..." maxlength="11">
                                                            @error('meter_number')
                                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                            @enderror
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div id="input-state"  class="p-5 flex flex-wrap items-end justify-end">         
                                                    <button type="submit" style="background-color: rgb(17, 17, 134)" class="btn btn-primary pl-5 pr-5 -mt-1 mr-2 -mb-2"> Fetch <div wire:loading.delay>ing... <i  data-color="white" class="fas fa-spinner fa-pulse w-4 h-4 ml-2"></i> </div> </button>
                                            </div>
                                            
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            </form>
                        </div>

                    </div>    
                </div>
            @endif
            @if($result == true)
                <div class="flex justify-center rounded-xl lg:text-xl sm:text-xs">
                    <div class="content" id="center">
                        <div class="grid grid-cols-12 gap-6 mt-5">
                            <div class="intro-y col-span-12 place-items-center lg:col-span-12">
                                <div class="intro-y box mt-5 " style="border-top: 3px solid blue">

                                    <div class="intro-y flex items-center mt-6 border-b border-gray-200 dark:border-dark-5 pb-4">
                                        <h2 class="text-lg font-medium mr-auto mt-4 ml-6">
                                          @if($tamper == true)  Electrix Meter Token @elseif($credit == true) Electrix Meter Credit @endif
                                        </h2>
                                    </div>

                                    <div class="intro-y box mt-5">
                                    
                                        <div id="inline-form" class="p-5">

                                            <div class="preview sm:mr-5 sm:ml-5">
                                                <div class="intro-y box sm:px-5 pt-5 mt-1">
                                                    <div class="flex flex-col lg:flex-row border-b border-gray-200 dark:border-dark-5 pb-5 -mx-5">
                                                        <div class="flex flex-2 sm:px-5 items-center justify-center lg:justify-start">
                                                            <div class="w-40 h-40 sm:w-44 sm:h-44 flex-none lg:w-52 lg:h-52 image-fit relative">
                                                                <img alt="logo" class="rounded-full" src="{{ asset('./dist/images/electrix-login.png') }}">
                                                            </div>
                                                        </div>
                                                        <div id="height"  class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                                            <div class="font-medium text-center lg:text-left lg:mt-3">@if($tamper == true) Clear Tamper Token @elseif($credit == true) Clear Credit Token @endif</div>
                                                            <div class="flex flex-col sm:justify-start sm:items-start lg:mt-6 sm:mt-0">
                                                                @if($tamper == true || $credit == true)
                                                                <div class="truncate sm:whitespace-normal flex items-center lg:mt-6"> 
                                                                    <span class="ml-2 mt-5"><i class="fa-solid fa-qrcode h-3 w-4 lg:mr-2"></i><strong class="lg:mr-5 font-medium lg:text-xl sm:text-sm">Token: </strong> <span class="text-blue-700">
                                                                        @if ($token == 'false01') Wrong Meter Number @else {{ $token }} @endif
                                                                    </span></span>
                                                                </div>
                                                                @endif
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            </div>
                        </div>    
                    </div>
                </div>
            @endif
        </div>
    </div>
    <!-- END: Content -->
</div>