@extends('../layout/' . $layout)

@section('title')
    Meter Actions | Electrix Vending
@endsection

@section('active-meters')
    side-menu--active
@endsection

@section('navigation')
    Meter Actions
@endsection

@section('navigation-url')
    meters
@endsection

@section('subcontent')
    @livewire('meter.meter-actions')
@endsection