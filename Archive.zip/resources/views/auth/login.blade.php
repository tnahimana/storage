@extends('layout.login')

@section('title')
    Login | Electrix Vending
@endsection

@section('content')
    @livewire('auth.login')
@endsection