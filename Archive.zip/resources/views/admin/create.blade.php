@extends('../layout/' . $layout)

@section('title')
    Register Admin | Electrix Vending
@endsection

@section('active-admin')
    side-menu--active
@endsection

@section('navigation')
    Register Admin
@endsection

@section('navigation-url')
    create
@endsection

@section('subcontent')
    @livewire('admin.admin-create')
@endsection