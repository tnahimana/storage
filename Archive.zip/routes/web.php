<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\APIController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AgentController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\LogoutController;
use App\Http\Controllers\DarkModeController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ShortcodeController;


Route::get('dark-mode-switcher', [DarkModeController::class, 'switch'])->name('dark-mode-switcher');

Route::get('/login', [AuthController::class, 'index'])->name('login');
Route::get('/', [AuthController::class, 'home']);
Route::get('/privacy-policy', [AuthController::class, 'privacy']);
Route::get('/terms&conditions', [AuthController::class, 'terms']);
Route::get('/apps', [AuthController::class, 'app']);
Route::get('get/{filename}', [AuthController::class, 'getfile']);

Route::group(['middleware' => ['auth']], function(){
    Route::get('/logout', [LogoutController::class, 'index'])->name('logout');
    Route::get('/dashboard', [DashboardController::class,'index'])->name('dashboard');
    Route::resource('/admins', AdminController::class);
    Route::resource('/agents', AgentController::class);
    Route::resource('/clients', ClientController::class);
    Route::resource('/meters', APIController::class);
    Route::resource('/updates', ShortcodeController::class);
});