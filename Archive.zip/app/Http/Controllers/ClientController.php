<?php

namespace App\Http\Controllers;

use App\Models\Clients;
use Illuminate\Http\Request;

class ClientController extends Controller
{
    public function __construct()
    {
        $this->middleware(['Moderator']);
    }

    public function index(){
        return view('client.index');
    }

    public function create(){
        if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin' || auth()->user()->role->name == 'agent'){
            return view('client.create');
        }else{
            return redirect()->back()->with('error', 'Unauthorized Access!');
        }
    }

    public function show($id){
        return view('client.show',[
            'client' => Clients::find($id),
        ]);
    }

    public function update($id){
        return view('client.update',[
            'client' => Clients::find($id),
        ]);
    }

    
}