<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AgentController extends Controller
{
    public function __construct()
    {
        $this->middleware(['Admin']);
    }

    public function index(){
        return view('agent.index');
    }

    public function create(){
        return view('agent.create');
    }

    public function show($id){
        return view('agent.show',[
            'agent' => $id,
        ]);
    }

    public function edit($id){
        return view('agent.update',[
            'agent' => $id,
        ]);
    }
}
