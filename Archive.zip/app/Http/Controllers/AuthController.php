<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\Cache\Store;
use Illuminate\Http\Request;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Storage;

class AuthController extends Controller
{
    public function __construct()
    {
        $this->middleware(['guest']);
    }

    public function index(){
        return view('auth.login');
    }

    public function home(){
        return view('home.index');
    }

    public function privacy(){
        return view('home.privacy');
    }

    public function terms(){
        return view('home.terms');
    }

    public function app(){
        return view('home.app');
    }

    public function getFile($filename){
        $path = 'storage/apps/'. $filename;
        $filePath = public_path($path);
        $headers = ['Content-Type: application/apk'];
        $fileName = 'Electrix'. $filename;
        return response()->download($filePath, $fileName, $headers);
    }

    public function logout()
    {
        auth()->user()->tokens()->delete();
        auth()->logout();
        return redirect('/login');
    }
}