<?php

namespace App\Http\Middleware;

use Closure;
use App\Models\User;
use Illuminate\Http\Request;

class Moderator
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
       if(auth()->user() != "")
       {
            $user = User::where('email', auth()->user()->email)->first();

            if(auth()->user()->role->name == 'super_admin' || auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'agent' || auth()->user()->role->name == 'client')
            {
                return $next($request);
            }
            return redirect('/logout');
       }

    }
}
