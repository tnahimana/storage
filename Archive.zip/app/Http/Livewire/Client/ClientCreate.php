<?php

namespace App\Http\Livewire\Client;

use App\Models\Cell;
use App\Models\Role;
use App\Models\User;
use App\Models\Sector;
use App\Models\Address;
use App\Models\Clients;
use App\Models\Village;
use Livewire\Component;
use App\Models\District;
use App\Models\Document;
use App\Models\Province;
use App\Models\RegMeter;
use App\Models\MobileUser;
use App\Models\WasacMeter;
use App\Models\ElectrixMeter;
use Illuminate\Support\Facades\Hash;

class ClientCreate extends Component
{
    public $firstname;
    public $middlename;
    public $lastname;
    public $email;
    public $phone;
    public $gender;
    public $document_type;
    public $meter_type;
    public $document_number;
    public $password;
    public $password_confirmation;
    public $province;
    public $meter_province;
    public $district;
    public $meter_district;
    public $sector;
    public $meter_sector;
    public $cell;
    public $meter_cell;
    public $village;
    public $meter_village;
    public $upi;
    public $street;
    public $reg_meter_number;
    public $meter_number1;
    public $meter_number2;
    public $meter_number3;
    public $meter_number4;
    public $meter_number5;
    public $meter_number6;
    public $meter_number7;
    public $meter_number8;
    public $meter_number9;
    public $meter_number10;
    public $selected;
    public $showPerson = true;
    public $showAddress = false;
    public $showRegMeter = false;
    public $showElectrixMeter = false;
    public $hidePrevious = false;
    public $hideNext = false;
    public $showSubmit = false;
    public $select_state = null;
    public $min = 11;
    public $min_nid = 16;
    public $unique;
    public $default = '|unique:reg_meters,reg_meter_number';
    public $regtype = false;
    public $upi_default = 'unique:reg_meters,land_upi';
    public $upi_set;

    public function render()
    {
        return view('livewire.client.client-create',[
            'document' => Document::get(),
            'provinces' => Province::get(),
            'meter_provinces' => Province::get(),
            'districts' => District::where('province_id', $this->province)->get(),
            'meter_districts' => District::where('province_id', $this->meter_province)->get(),
            'sectors' => Sector::where('district_id', $this->district)->get(),
            'meter_sectors' => Sector::where('district_id', $this->meter_district)->get(),
            'cells' => Cell::where('sector_id', $this->sector)->get(),
            'meter_cells' => Cell::where('sector_id', $this->meter_sector)->get(),
            'villages' => Village::where('cell_id', $this->cell)->get(),
            'meter_villages' => Village::where('cell_id', $this->meter_cell)->get(),
        ]);
    }

    protected function rules(){  
        return [
            'firstname'=> 'required | string | min:3 ',
            'middlename'=> 'string',
            'lastname'=> 'required | string | min:3 ',
            'gender'=> 'required',
            'email'=> 'required | email | unique:users',
            'document_type'=> 'required',
            'document_number'=> 'required | min:' . $this->min_nid . '| unique:clients',
            'phone'=> 'required | numeric | regex:/^([0-9\s\-\+\(\)]*)$/|digits:10 | unique:clients',
            'password'=> 'required | min:8',
            'password_confirmation'=> 'required | min:8 | same:password',
            'province' => 'required',
            'meter_province' => 'required',
            'district' => 'required',
            'meter_district' => 'required',
            'sector' => 'required',
            'meter_sector' => 'required',
            'cell' => 'required',
            'meter_type' => 'required',
            'meter_cell' => 'required',
            'village' => 'required',
            'meter_village' => 'required',
            'street' => 'required| string',
            'upi' => 'min:15|' . $this->upi_default,
            'reg_meter_number' => 'required|' . $this->min . $this->default,
            'meter_number1' => 'required|numeric|unique:electrix_meters,electrix_meter_number|digits:11',
            'meter_number2' => 'required|numeric|unique:electrix_meters,electrix_meter_number|digits:11',
            'meter_number3' => 'required|numeric|unique:electrix_meters,electrix_meter_number|digits:11',
            'meter_number4' => 'required|numeric|unique:electrix_meters,electrix_meter_number|digits:11',
            'meter_number5' => 'required|numeric|unique:electrix_meters,electrix_meter_number|digits:11',
            'meter_number6' => 'required|numeric|unique:electrix_meters,electrix_meter_number|digits:11',
            'meter_number7' => 'required|numeric|unique:electrix_meters,electrix_meter_number|digits:11',
            'meter_number8' => 'required|numeric|unique:electrix_meters,electrix_meter_number|digits:11',
            'meter_number9' => 'required|numeric|unique:electrix_meters,electrix_meter_number|digits:11',
            'meter_number10' => 'required|numeric|unique:electrix_meters,electrix_meter_number|digits:11',
            'selected' => 'required',
        ];
    }

    protected function messages(){
        return [
            'reg_meter_number.required' => $this->regtype ? 'Reg meter number is required' : 'Wasac meter number is required',
            'reg_meter_number.min' => $this->regtype ? 'Reg meter number must be 11 digits minimum' : 'Wasac meter number must be 9 digits minimum',
            'reg_meter_number.unique' => $this->regtype ? 'This Reg meter number has already been taken' : 'This Wasac meter number has already been taken',
        ];
    }

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
        if($this->meter_type == 'Energy Meter'){
            $this->regtype = true;
            $this->default = null;
            $this->min = 'min:'. 11 .'|';
            $this->unique = 'reg_meters,reg_meter_number';
            $this->default = 'unique:'.$this->unique;
            $this->upi_set = 'unique:reg_meters,land_upi';
            $this->upi_default = $this->upi_set;
        }elseif($this->meter_type == 'Water Meter'){
            $this->regtype = false;
            $this->default = null;
            $this->min = 'min:'. 9 . '|';
            $this->unique = 'wasac_meters,wasac_meter_number';
            $this->default = 'unique:'.$this->unique;
            $this->upi_set = 'unique:wasac_meters,land_upi';
            $this->upi_default = $this->upi_set;
        }
        if($this->document_type == 1){
            $this->min_nid = 16;
        }else{
            $this->min_nid = 8;    
        }
    }

    public function previous(){
        if($this->showPerson){
            $this->hidePrevious = true;
            $this->hideNext = false;
        }elseif($this->showAddress){
            $this->hidePrevious = false;
            $this->hideNext = false;
            $this->showPerson = true;
            $this->showAddress = false;
            $this->showRegMeter = false;
            $this->showElectrixMeter = false;
            $this->reg_meter_number = null;
        }elseif($this->showRegMeter){
            $this->hidePrevious = false;
            $this->hideNext = false;
            $this->showPerson = false;
            $this->showAddress = true;
            $this->showRegMeter = false;
            $this->showElectrixMeter = false;
            $this->showSubmit = false;
        }elseif($this->showElectrixMeter){
            $this->select_state = $this->selected;
            $this->hidePrevious = false;
            $this->hideNext = false;
            $this->showPerson = false;
            $this->showAddress = false;
            $this->showRegMeter = true;
            $this->showElectrixMeter = false;
            $this->showSubmit = false;
        }
    }

    public function next(){
        if($this->showPerson){

            $this->validatePerson();
            if($this->validatePerson()){
                $this->hidePrevious = false;
                $this->hideNext = false;
                $this->showPerson = false;
                $this->showAddress = true;
                $this->showRegMeter = false;
                $this->showElectrixMeter = false;
            }
        }elseif($this->showAddress){
            $this->validateAddress();
            if($this->validateAddress()){
                $this->hidePrevious = false;
                $this->hideNext = false;
                $this->showPerson = false;
                $this->showAddress = false;
                $this->showRegMeter = true;
                $this->showElectrixMeter = false;
            }
        }elseif($this->showRegMeter){
            $this->validateRegMeter();
            if($this->select_state > $this->selected){
                $this->meter_number1 = null;
                $this->meter_number2 = null;
                $this->meter_number3 = null;
                $this->meter_number4 = null;
                $this->meter_number5 = null;
                $this->meter_number6 = null;
                $this->meter_number7 = null;
                $this->meter_number8 = null;
                $this->meter_number9 = null;
                $this->meter_number10 = null;
            }
            if($this->validateRegMeter()){
                $this->hidePrevious = false;
                $this->showPerson = false;
                $this->showAddress = false;
                $this->showRegMeter = false;
                $this->showElectrixMeter = true;
                $this->hideNext = true;
                $this->showSubmit = true;
            }
        }elseif($this->showElectrixMeter){
            $this->validateElectrixMeter();
        }
    }

    public function validatePerson(){
        $this->validateOnly('firstname');
        $this->validateOnly('lastname');
        $this->validateOnly('email');
        $this->validateOnly('phone');
        $this->validateOnly('dob');
        $this->validateOnly('gender');
        $this->validateOnly('document_type');
        $this->validateOnly('document_number');

        return true;
    }

    public function validateAddress(){
        $this->validateOnly('province');
        $this->validateOnly('district');
        $this->validateOnly('sector');
        $this->validateOnly('cell');
        $this->validateOnly('village');
        $this->validateOnly('meter_type');

        return true;
    }

    public function validateRegMeter(){
        $this->validateOnly('reg_meter_number');
        $this->validateOnly('meter_province');
        $this->validateOnly('meter_district');
        $this->validateOnly('meter_sector');
        $this->validateOnly('meter_cell');
        $this->validateOnly('meter_village');
         $this->validateOnly('street');
        $this->validateOnly('selected');

        return true;
    }

    public function validateElectrixMeter(){
        if($this->selected == 1){
            $this->validateOnly('meter_number1');
            $this->resetValidation();
        }elseif($this->selected == 2){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->resetValidation();
        }elseif($this->selected == 3){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->resetValidation();
        }elseif($this->selected == 4){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->validateOnly('meter_number4');
            $this->resetValidation();
        }elseif($this->selected == 5){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->validateOnly('meter_number4');
            $this->validateOnly('meter_number5');
            $this->resetValidation();
        }elseif($this->selected == 6){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->validateOnly('meter_number4');
            $this->validateOnly('meter_number5');
            $this->validateOnly('meter_number6');
            $this->resetValidation();
        }elseif($this->selected == 7){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->validateOnly('meter_number4');
            $this->validateOnly('meter_number5');
            $this->validateOnly('meter_number6');
            $this->validateOnly('meter_number7');
            $this->resetValidation();
        }elseif($this->selected == 8){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->validateOnly('meter_number4');
            $this->validateOnly('meter_number5');
            $this->validateOnly('meter_number6');
            $this->validateOnly('meter_number7');
            $this->validateOnly('meter_number8');
            $this->resetValidation();
        }elseif($this->selected == 9){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->validateOnly('meter_number4');
            $this->validateOnly('meter_number5');
            $this->validateOnly('meter_number6');
            $this->validateOnly('meter_number7');
            $this->validateOnly('meter_number8');
            $this->validateOnly('meter_number9');
            $this->resetValidation();
        }elseif($this->selected == 10){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->validateOnly('meter_number4');
            $this->validateOnly('meter_number5');
            $this->validateOnly('meter_number6');
            $this->validateOnly('meter_number7');
            $this->validateOnly('meter_number8');
            $this->validateOnly('meter_number9');
            $this->validateOnly('meter_number10');
            $this->resetValidation();
        }
        return true;
    }

    public function userStore(){
        $role = Role::where('name', 'client')->first();
        $user = User::create([
            'username' => $this->email,
            'email' => $this->email,
            'role_id' => $role->id,
            'password' => Hash::make($this->phone),
        ]);
        return $user;
    }

    public function adddressStore(){
        if(Address::where('village_id', $this->village)->first() == null){
            Address::create([
                'province_id' => $this->province,
                'district_id' => $this->district,
                'sector_id' => $this->sector,
                'cell_id' => $this->cell,
                'village_id' => $this->village,
            ]);
        }
        $address = Address::where('village_id', $this->village)->first();
        return $address->id;
    } 

    public function clientStore(){
        $user = $this->userStore();
        $this->mobileUserStore($user);
        $address_id = $this->adddressStore();
        $client = Clients::create([
            'firstname' => $this->firstname,
            'middlename' => $this->middlename,
            'lastname' => $this->lastname,
            'email' => $this->email,
            'phone' => $this->phone,
            'gender' => $this->gender,
            'user_id' => $user->id,
            'role_id' => $user->role_id,
            'address_id' => $address_id,
            'document_id' => $this->document_type,
            'document_number' => $this->document_number,
            'register_id' => auth()->user()->id,
            'password' => Hash::make($this->phone),
        ]);
        return $client;
    }

    public function regStore(){
        $client = $this->clientStore();
        $reg_meter = RegMeter::create([
            'client_id' => $client->id,
            'land_upi' => $this->upi,
            'reg_meter_number' => $this->reg_meter_number,
            'meter_province_id' => $this->meter_province,
            'meter_district_id' => $this->meter_district,
            'meter_sector_id' => $this->meter_sector,
            'meter_cell_id' => $this->meter_cell,
            'meter_village_id' => $this->meter_village,
            'meter_street_address' => $this->street,
            'meter_type' => $this->meter_type,
            'user_id' => auth()->user()->id,
        ]);
        return $reg_meter;
    }

    public function wasacStore(){
        $client = $this->clientStore();
        $wasac_meter = WasacMeter::create([
            'client_id' => $client->id,
            'land_upi' => $this->upi,
            'wasac_meter_number' => $this->reg_meter_number,
            'meter_province_id' => $this->meter_province,
            'meter_district_id' => $this->meter_district,
            'meter_sector_id' => $this->meter_sector,
            'meter_cell_id' => $this->meter_cell,
            'meter_village_id' => $this->meter_village,
            'meter_street_address' => $this->street,
            'meter_type' => $this->meter_type,
            'user_id' => auth()->user()->id,
        ]);
        return $wasac_meter;
    }

    public function electrixStore(){
        if($this->meter_type == 'Energy Meter'){
            $reg_meter = $this->regStore();
            $meters = [
                $this->meter_number1,
                $this->meter_number2,
                $this->meter_number3,
                $this->meter_number4,
                $this->meter_number5,
                $this->meter_number6,
                $this->meter_number7,
                $this->meter_number8,
                $this->meter_number9,
                $this->meter_number10,
            ];
            $meters = array_filter($meters);
            foreach($meters as $item){
                $electrix = ElectrixMeter::create([
                    'reg_meter_id' => $reg_meter->id,
                    'electrix_meter_number' => $item,
                    'user_id' => auth()->user()->id,
                ]);
            }
            if($electrix){
                session()->flash('success', 'Client added Successfully!');
                $client = Clients::where('email', $this->email)->first();
                $this->reset();
                return redirect()->to('/clients/'. $client->id)->with('success', 'Client added Successfully!');
            }else{
                return back()->with('error', 'Something went wrong!');
            } 
        }else{
          $wasac_meter = $this->wasacStore(); 
          $meters = [
                $this->meter_number1,
                $this->meter_number2,
                $this->meter_number3,
                $this->meter_number4,
                $this->meter_number5,
                $this->meter_number6,
                $this->meter_number7,
                $this->meter_number8,
                $this->meter_number9,
                $this->meter_number10,
            ];
            $meters = array_filter($meters);
            foreach($meters as $item){
                $electrix = ElectrixMeter::create([
                    'wasac_meter_id' => $wasac_meter->id,
                    'electrix_meter_number' => $item,
                    'user_id' => auth()->user()->id,
                ]);
            }
            if($electrix){
                session()->flash('success', 'Client added Successfully!');
                $client = Clients::where('email', $this->email)->first();
                $this->reset();
                return redirect()->to('/clients/'. $client->id)->with('success', 'Client added Successfully!');
            }else{
                return back()->with('error', 'Something went wrong!');
            }  
        }
    }

    public function save()
    {
        if(auth()->user()->role->name != 'client'){
            $this->electrixStore();        
        }else{
            return redirect()->to('/dashbaord')->with('error', 'Unauthorized Action!');
        }
    }

    public function mobileUserStore($user){
        $mobile = MobileUser::create([
            'user_id' => $user->id,
            'firstname' => $this->firstname,
            'middlename' => $this->middlename,
            'lastname' => $this->lastname,
            'email' => $this->email,
            'phone' => $this->phone,
            'password' => Hash::make($this->password),
        ]);
        return $mobile;
    }

}