<?php

namespace App\Http\Livewire\Client;

use App\Models\Cell;
use App\Models\Image;
use App\Models\Sector;
use App\Models\Clients;
use App\Models\Village;
use Livewire\Component;
use App\Models\District;
use App\Models\Province;
use App\Models\RegMeter;
use App\Models\WasacMeter;
use Livewire\WithPagination;
use App\Models\ElectrixMeter;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Storage;

class ClientShow extends Component
{
    use WithPagination;
    use WithFileUploads;

    public $client;
    public $image;
    public $personalInfo = true;
    public $contactInfo = false;
    public $addressInfo = false;
    public $showAddress = false;
    public $showSelected = false;
    public $showImage = false;
    public $regMeter = false;
    public $wasacMeter = false;
    public $showElectrix = false;
    public $perPage = 5;
    public $search = null;
    public $client_id;
    public $i = 1;
    public $electrixMeter;
    public $mainMeter;
    public $meter;
    public $meterLocation = false;
    public $showClient = true;
    public $addMeter = false;
    public $showRegMeter = false;
    public $showElectrixMeter = false;
    public $hidePrevious = false;
    public $hideNext = false;
    public $showSubmit = false;
    public $select_state = null;
    public $meter_province;
    public $meter_district;
    public $meter_sector;
    public $meter_cell;
    public $meter_village;
    public $upi;
    public $reg_meter_number;
    public $street;
    public $selected;
    public $meter_number1;
    public $meter_number2;
    public $meter_number3;
    public $meter_number4;
    public $meter_number5;
    public $meter_number6;
    public $meter_number7;
    public $meter_number8;
    public $meter_number9;
    public $meter_number10;
    public $addElectrix = false;
    public $showSeleted = false;
    public $owner;
    public $electrix;
    public $requiredMeterNumber = false;
    public $wasacSelected = false;
    public $regSelected = false;
    public $regElectrixInfo = false;
    public $wasacElectrixInfo = false;
    public $wasactype = false;
    public $regtype = false;
    public $min;
    public $min_default = 11;
    public $unique; 
    public $default = 'unique:reg_meters|min:'; 
    public $upi_default = 'unique:reg_meters,land_upi';
    public $upi_set;

    public function render()
    {
        $meters = RegMeter::search($this->search)->where('client_id', $this->client_id)->paginate($this->perPage);
        $wasacMeters = WasacMeter::search($this->search)->where('client_id', $this->client_id)->paginate($this->perPage);
        return view('livewire.client.client-show',[
            'meters' => $meters,
            'wasac_meters' => $wasacMeters,
            'meter_provinces' => Province::get(),
            'meter_districts' => District::where('province_id', $this->meter_province)->get(),
            'meter_sectors' => Sector::where('district_id', $this->meter_district)->get(),
            'meter_cells' => Cell::where('sector_id', $this->meter_sector)->get(),
            'meter_villages' => Village::where('cell_id', $this->meter_cell)->get(),
        ]);
    }

    public function mount($id){
        $this->client = Clients::find($id);
        $this->client_id = $id;
        $this->showImage = false;
    }

    public function personalInfo(){
        $this->personalInfo = true;
        $this->contactInfo = false;
        $this->addressInfo = false;
        $this->regMeter = false;
        $this->wasacMeter = false;
        $this->showElectrix = false;
        $this->meterLocation = false;
    }

    public function contactInfo(){
        $this->personalInfo = false;
        $this->contactInfo = true;
        $this->addressInfo = false;
        $this->regMeter = false;
        $this->wasacMeter = false;
        $this->showElectrix = false;
        $this->meterLocation = false;
    }

    public function addressInfo(){
        $this->personalInfo = false;
        $this->contactInfo = false;
        $this->addressInfo = true;
        $this->regMeter = false;
        $this->wasacMeter = false;
        $this->showElectrix = false;
        $this->meterLocation = false;
    }

    public function RegMeterInfo(){
        $this->personalInfo = false;
        $this->contactInfo = false;
        $this->addressInfo = false;
        $this->regMeter = true;
        $this->regSelected = true;
        $this->wasacSelected = false;
        $this->wasacMeter = false;
        $this->showElectrix = false;
        $this->regElectrixInfo = false;
        $this->wasacElectrixInfo = false;
        $this->meterLocation = false;
    }

    public function WasacMeterInfo(){
        $this->personalInfo = false;
        $this->contactInfo = false;
        $this->addressInfo = false;
        $this->regMeter = false;
        $this->wasacMeter = true;
        $this->wasacSelected = true;
        $this->regSelected = false;
        $this->showElectrix = false;
        $this->regElectrixInfo = false;
        $this->wasacElectrixInfo = false;
        $this->meterLocation = false;
    }

    public function electrixMeter(){
        $this->personalInfo = false;
        $this->contactInfo = false;
        $this->addressInfo = false;
        $this->regMeter = false;
        $this->wasacMeter = false;
        $this->showElectrix = true;
        $this->meterLocation = false;
        return $this->showElectrix;
    }

    public function ShowLocation($id){
        $this->electrixMeter();
        if($this->regSelected){
            $this->meter = RegMeter::where('id', $id)->first();
            $this->personalInfo = false;
            $this->contactInfo = false;
            $this->addressInfo = false;
            $this->regMeter = false;
            $this->wasacMeter = false;
            $this->showElectrix = false;
            $this->meterLocation = true;
        }
        if($this->wasacSelected){
            $this->meter = WasacMeter::where('id', $id)->first();
            $this->personalInfo = false;
            $this->contactInfo = false;
            $this->addressInfo = false;
            $this->regMeter = false;
            $this->wasacMeter = false;
            $this->showElectrix = false;
            $this->meterLocation = true;
        }
    }

    public function addImage(){
        $this->showImage = true;
    }

    protected function rules(){  
        return [
            'image' => 'required|image|max:1024',
            'meter_province' => 'required',
            'meter_district' => 'required',
            'meter_sector' => 'required',
            'meter_cell' => 'required',
            'meter_village' => 'required',
            'street' => 'required| string',
            'upi' => 'min:15|' . $this->upi_default,
            'reg_meter_number' => 'required|'. $this->default . $this->min_default,
            'meter_number1' => 'required|min:11|numeric|unique:electrix_meters,electrix_meter_number',
            'meter_number2' => 'required|min:11|numeric|unique:electrix_meters,electrix_meter_number',
            'meter_number3' => 'required|min:11|numeric|unique:electrix_meters,electrix_meter_number',
            'meter_number4' => 'required|min:11|numeric|unique:electrix_meters,electrix_meter_number',
            'meter_number5' => 'required|min:11|numeric|unique:electrix_meters,electrix_meter_number',
            'meter_number6' => 'required|min:11|numeric|unique:electrix_meters,electrix_meter_number',
            'meter_number7' => 'required|min:11|numeric|unique:electrix_meters,electrix_meter_number',
            'meter_number8' => 'required|min:11|numeric|unique:electrix_meters,electrix_meter_number',
            'meter_number9' => 'required|min:11|numeric|unique:electrix_meters,electrix_meter_number',
            'meter_number10' => 'required|min:11|numeric|unique:electrix_meters,electrix_meter_number',
            'selected' => 'required',
        ];
    }

    protected function messages(){
        return [
            'reg_meter_number.required' => $this->regtype ? 'Reg meter number is required' : 'Wasac meter number is required',
            'reg_meter_number.min' => $this->regtype ? 'Reg meter number must be '.$this->min_default.' digits minimum' : 'Wasac meter number must be '.$this->min_default.' digits minimum',
            'reg_meter_number.unique' => $this->regtype ? 'This Reg meter number has already been taken' : 'This Wasac meter number has already been taken',
        ];
    }

    public function updated($propertyName){
        $this->validateOnly($propertyName);
        if($this->regtype){
            $this->min = 11;
            $this->default = null;
            $this->min_default = null;
            $this->unique = 'unique:reg_meters,reg_meter_number|min:';
            $this->upi_set = 'unique:reg_meters,land_upi';
            $this->min_default = $this->min;
            $this->upi_default = $this->upi_set;
            $this->default = $this->unique;
        }elseif($this->wasactype){
            $this->min = 9;
            $this->default = null;
            $this->min_default = null;
            $this->unique = 'unique:wasac_meters,wasac_meter_number|min:';
            $this->upi_set = 'unique:wasac_meters,land_upi';
            $this->min_default = $this->min;
            $this->default = $this->unique;
            $this->upi_default = $this->upi_set;
        }
    }

    public function hydrate()
    {
    }

    public function upload($id){
        $validatedData = $this->validateOnly('image');
        $this->previous_image($id);
        $image = $this->saveImage($this->image, 'images');
        if($this->previous_image($id) == false){
            $saveImage = Image::create([
                'img_url' => $image
            ]);
        }else{
            $saveImage = Image::where('id',$this->previous_image($id))->update([
                'img_url' => $image
            ]);
        }
        if($saveImage){
            $image_id = Image::where('img_url',$image)->latest()->first();
        }
        Clients::find($id)->update([
            'image_id' => $image_id->id
        ]);
        $this->shiftPage();
        $this->resetImage();
        return $this->mount($id);
    }

    public function resetImage(){
        $this->showImage = false;
        $this->resetValidation();
        $this->image = null;
    }

    public function previous_image($id){
        $client = Clients::find($id);
        if($client->image_id != null){
            $image = Image::find($client->image_id);
            $image_path = $image->img_url;
            if(Storage::exists($image_path)){
                Storage::delete($image_path);
            }
            return $image->id;
        }else{
            return false;
        }
    }

    public function shiftPage(){
        if($this->personalInfo){
            return $this->contactInfo();
        }elseif($this->contactInfo){
            return $this->personalInfo();
        }elseif($this->addressInfo){
            return $this->personalInfo();
        }elseif($this->regMeter){
            return $this->personalInfo();
        }elseif($this->electrixMeter){
            if($this->regSelected){
                return $this->RegMeterInfo();
            }elseif($this->wasacSelected){
                return $this->WasacMeterInfo();
            }
        }
    }

    public function activateMeter($id, $client){
        RegMeter::where('id',$id)->update([
            'meter_status' => 'Active',
        ]);
        session()->flash('success', 'Meter Activated!');
        return $this->mount($client);
    }

    public function deactivateMeter($id, $client){
        RegMeter::where('id',$id)->update([
            'meter_status' => 'Inactive',
        ]);
        session()->flash('success', 'Meter Deactivated!');
        return $this->mount($client);
    }

    public function electrixActivate($id, $client){
        ElectrixMeter::where('id',$id)->update([
            'meter_status' => 'Active',
        ]);
        $this->shiftPage();
        session()->flash('success', 'Meter Activated!');
        return $this->mount($client);
    }

    public function electrixDeactivate($id, $client){
        ElectrixMeter::where('id',$id)->update([
            'meter_status' => 'Inactive',
        ]);
        $this->shiftPage();
        session()->flash('success', 'Meter Deactivated!');
        return $this->mount($client);
    }

    public function  ShowElectrixReg($id, $client){
        $this->electrixMeter();
        if($this->electrixMeter()){
                $this->regElectrixInfo = true;
                $this->wasacElectrixInfo = false;
                $this->electrixMeter = ElectrixMeter::where('reg_meter_id', $id)->get();
                $this->mainMeter = RegMeter::where('client_id', $client)->where('id', $id)->first();
           
            return $this->mount($client);
        }
    }

    public function  ShowElectrixWasac($id, $client){
        $this->electrixMeter();
        if($this->electrixMeter()){
                $this->regElectrixInfo = false;
                $this->wasacElectrixInfo = true;
                $this->electrixMeter = ElectrixMeter::where('wasac_meter_id', $id)->get();
                $this->mainMeter = WasacMeter::where('client_id', $client)->where('id', $id)->first();
            
            return $this->mount($client);
        }
    }

    public function showAddMeter($regtype, $wasactype){
        $this->addMeter = true;
        $this->showClient = false;
        if($regtype){
            $this->regtype =  true;
            $this->showRegMeter = true;
        }elseif($wasactype){
            $this->showRegMeter = true;
            $this->wasactype =  true;
        }
    }
    
    public function previous(){
        if($this->showRegMeter){
            $this->hidePrevious = false;
            $this->hideNext = false;
            $this->showAddress = true;
            $this->showRegMeter = false;
            $this->showElectrixMeter = false;
            $this->showSubmit = false;
        }elseif($this->showElectrixMeter){
            $this->select_state = $this->selected;
            $this->hidePrevious = false;
            $this->hideNext = false;
            $this->showAddress = false;
            $this->showRegMeter = true;
            $this->showElectrixMeter = false;
            $this->showSubmit = false;
        }
    }

    public function previousElectrix(){
        if($this->showElectrixMeter){
            $this->select_state = $this->selected;
            $this->hidePrevious = false;
            $this->hideNext = false;
            $this->showAddress = false;
            $this->showSelected = true;
            $this->showElectrixMeter = false;
            $this->showSubmit = false;
        }
    }

    public function next(){
        if($this->showRegMeter){
            $this->validateRegMeter();
            if($this->select_state > $this->selected){
                $this->meter_number1 = null;
                $this->meter_number2 = null;
                $this->meter_number3 = null;
                $this->meter_number4 = null;
                $this->meter_number5 = null;
                $this->meter_number6 = null;
                $this->meter_number7 = null;
                $this->meter_number8 = null;
                $this->meter_number9 = null;
                $this->meter_number10 = null;
            }
            if($this->validateRegMeter()){
                $this->hidePrevious = false;
                $this->showRegMeter = false;
                $this->showElectrixMeter = true;
                $this->hideNext = true;
                $this->showSubmit = true;
            }
        }elseif($this->showElectrixMeter){
            $this->validateElectrixMeter();
        }
    }

    public function nextElectrix(){
        if($this->showSelected){
            $this->validateOnly('selected');
            if($this->select_state > $this->selected){
                $this->meter_number1 = null;
                $this->meter_number2 = null;
                $this->meter_number3 = null;
                $this->meter_number4 = null;
                $this->meter_number5 = null;
                $this->meter_number6 = null;
                $this->meter_number7 = null;
                $this->meter_number8 = null;
                $this->meter_number9 = null;
                $this->meter_number10 = null;
            }
            $this->hidePrevious = false;
            $this->showSelected = false;
            $this->showElectrixMeter = true;
            $this->hideNext = true;
            $this->showSubmit = true;

        }elseif($this->showElectrixMeter){
            $this->validateElectrixMeter();
        }
    }

    public function validateRegMeter(){
        $this->validateOnly('reg_meter_number');
        $this->validateOnly('meter_province');
        $this->validateOnly('meter_district');
        $this->validateOnly('meter_sector');
        $this->validateOnly('meter_cell');
        $this->validateOnly('meter_village');
         $this->validateOnly('street');
        $this->validateOnly('selected');
        return true;
    }

    public function validateElectrixMeter(){
        if($this->selected == 1){
            $this->validateOnly('meter_number1');
            $this->resetValidation();
        }elseif($this->selected == 2){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->resetValidation();
        }elseif($this->selected == 3){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->resetValidation();
        }elseif($this->selected == 4){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->validateOnly('meter_number4');
            $this->resetValidation();
        }elseif($this->selected == 5){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->validateOnly('meter_number4');
            $this->validateOnly('meter_number5');
            $this->resetValidation();
        }elseif($this->selected == 6){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->validateOnly('meter_number4');
            $this->validateOnly('meter_number5');
            $this->validateOnly('meter_number6');
            $this->resetValidation();
        }elseif($this->selected == 7){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->validateOnly('meter_number4');
            $this->validateOnly('meter_number5');
            $this->validateOnly('meter_number6');
            $this->validateOnly('meter_number7');
            $this->resetValidation();
        }elseif($this->selected == 8){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->validateOnly('meter_number4');
            $this->validateOnly('meter_number5');
            $this->validateOnly('meter_number6');
            $this->validateOnly('meter_number7');
            $this->validateOnly('meter_number8');
            $this->resetValidation();
        }elseif($this->selected == 9){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->validateOnly('meter_number4');
            $this->validateOnly('meter_number5');
            $this->validateOnly('meter_number6');
            $this->validateOnly('meter_number7');
            $this->validateOnly('meter_number8');
            $this->validateOnly('meter_number9');
            $this->resetValidation();
        }elseif($this->selected == 10){
            $this->validateOnly('meter_number1');
            $this->validateOnly('meter_number2');
            $this->validateOnly('meter_number3');
            $this->validateOnly('meter_number4');
            $this->validateOnly('meter_number5');
            $this->validateOnly('meter_number6');
            $this->validateOnly('meter_number7');
            $this->validateOnly('meter_number8');
            $this->validateOnly('meter_number9');
            $this->validateOnly('meter_number10');
            $this->resetValidation();
        }
        return true;
    }

    public function regStore($id){
        $client = Clients::find($id);
        $reg_meter = RegMeter::create([
            'client_id' => $client->id,
            'land_upi' => $this->upi,
            'reg_meter_number' => $this->reg_meter_number,
            'meter_province_id' => $this->meter_province,
            'meter_district_id' => $this->meter_district,
            'meter_sector_id' => $this->meter_sector,
            'meter_cell_id' => $this->meter_cell,
            'meter_village_id' => $this->meter_village,
            'meter_street_address' => $this->street,
            'user_id' => auth()->user()->id,
        ]);
        return $reg_meter;
    }

    public function wasacStore($id){
        $client = Clients::find($id);
        $wasac_meter = WasacMeter::create([
            'client_id' => $client->id,
            'land_upi' => $this->upi,
            'wasac_meter_number' => $this->reg_meter_number,
            'meter_province_id' => $this->meter_province,
            'meter_district_id' => $this->meter_district,
            'meter_sector_id' => $this->meter_sector,
            'meter_cell_id' => $this->meter_cell,
            'meter_village_id' => $this->meter_village,
            'meter_street_address' => $this->street,
            'user_id' => auth()->user()->id,
        ]);
        return $wasac_meter;
    }

    public function electrixStore($id){
        if($this->validateElectrixMeter()){
            if($this->meter_number1 != null){
                if($this->regtype){
                    $reg_meter = $this->regStore($id);
                    $meters = [
                        $this->meter_number1,
                        $this->meter_number2,
                        $this->meter_number3,
                        $this->meter_number4,
                        $this->meter_number5,
                        $this->meter_number6,
                        $this->meter_number7,
                        $this->meter_number8,
                        $this->meter_number9,
                        $this->meter_number10,
                    ];
                    $meters = array_filter($meters);
                    foreach($meters as $item){
                        $this->electrix = ElectrixMeter::create([
                            'reg_meter_id' => $reg_meter->id,
                            'electrix_meter_number' => $item,
                            'user_id' => auth()->user()->id,
                        ]);
                    }
                }elseif($this->wasactype){
                    $wasac_meter = $this->wasacStore($id);
                    $meters = [
                        $this->meter_number1,
                        $this->meter_number2,
                        $this->meter_number3,
                        $this->meter_number4,
                        $this->meter_number5,
                        $this->meter_number6,
                        $this->meter_number7,
                        $this->meter_number8,
                        $this->meter_number9,
                        $this->meter_number10,
                    ];
                    $meters = array_filter($meters);
                    foreach($meters as $item){
                        $this->electrix = ElectrixMeter::create([
                            'wasac_meter_id' => $wasac_meter->id,
                            'electrix_meter_number' => $item,
                            'user_id' => auth()->user()->id,
                        ]);
                    }
                }
                if($this->electrix != null){
                    if($this->regtype){
                        session()->flash('success', 'Meter added Successfully!');
                        $client = Clients::find($id);
                        $this->resetVars();
                        $this->showClient = true;
                        return redirect()->to('/clients/' . $client->id)->with('success', 'Meter added Successfully!');
                    }elseif($this->wasactype){
                        session()->flash('success', 'Meter added Successfully!');
                        $client = Clients::find($id);
                        $this->resetVars();
                        $this->showClient = true;
                        return redirect()->to('/clients/' . $client->id)->with('success', 'Meter added Successfully!');
                    }
                }else{
                    return;
                } 
            }else{
                return $this->requiredMeterNumber = true;
            }
        }else{
            return back()->with('error', 'Oops, Something went wrong!');
        }
    }

    public function addRegMeter($id){
        $this->regtype= true; 
        $this->wasactype= false; 
        $this->hidePrevious = true;
        $this->showAddMeter($this->regtype, $this->wasactype);
    }

    public function addWasacMeter($id){
        $this->regtype= false; 
        $this->wasactype= true;
        $this->hidePrevious = true;
        $this->showAddMeter($this->regtype, $this->wasactype);
    }

    public function save($id)
    {
        $this->electrixStore($id);        
    }

    public function resetVars(){
        $this->upi = null;
        $this->reg_meter_number = null;
        $this->meter_province = null;
        $this->meter_district = null;
        $this->meter_sector = null;
        $this->meter_cell = null;
        $this->meter_village = null;
        $this->street = null;
        $this->selected = null;
        $this->meter_number1 = null;
        $this->meter_number2 = null;
        $this->meter_number3 = null;
        $this->meter_number4 = null;
        $this->meter_number5 = null;
        $this->meter_number6 = null;
        $this->meter_number7 = null;
        $this->meter_number8 = null;
        $this->meter_number9 = null;
        $this->meter_number10 = null;
    }

    public function back(){
        $this->addMeter = false;
        $this->showClient = true;
        $this->showRegMeter = false;
        $this->resetVars();
    }

    public function electrixShow(){
        $this->addMeter = false;
        $this->showClient = false;
        $this->showRegMeter = false;
        $this->addElectrix = true;
        $this->showSelected = true;
    }

    public function electrixOnlyStore($id){
        if($this->validateElectrixMeter()){
            $reg_meter = RegMeter::find($id);
            $wasac_meter = WasacMeter::find($id);
            if($this->meter_number1 != ""){
                $meters = [
                    $this->meter_number1,
                    $this->meter_number2,
                    $this->meter_number3,
                    $this->meter_number4,
                    $this->meter_number5,
                    $this->meter_number6,
                    $this->meter_number7,
                    $this->meter_number8,
                    $this->meter_number9,
                    $this->meter_number10,
                ];
                $meters = array_filter($meters);
                if($this->regtype){
                    foreach($meters as $item){
                        $this->electrix = ElectrixMeter::create([
                            'reg_meter_id' => $reg_meter->id,
                            'electrix_meter_number' => $item,
                            'user_id' => auth()->user()->id,
                        ]);
                    }
                    if($this->electrix != null){
                        session()->flash('success', 'Meter added Successfully!');
                        $this->resetVars();
                        $this->showClient = true;
                        $this->shiftPage();
                        $this->previous();
                        $this->ShowElectrixReg($reg_meter->id, $reg_meter->client_id);
                        return back()->with('success', 'Meter added Successfully!');
                    }else{
                        return;
                    } 
                }elseif($this->wasactype){
                    foreach($meters as $item){
                        $this->electrix = ElectrixMeter::create([
                            'wasac_meter_id' => $wasac_meter->id,
                            'electrix_meter_number' => $item,
                            'user_id' => auth()->user()->id,
                        ]);
                    }
                    if($this->electrix != null){
                        session()->flash('success', 'Meter added Successfully!');
                        $this->resetVars();
                        $this->showClient = true;
                        $this->shiftPage();
                        $this->previous();
                        $this->ShowElectrixWasac($wasac_meter->id, $wasac_meter->client_id);
                        return back()->with('success', 'Meter added Successfully!');
                    }else{
                        return;
                    } 
                }
            } else {
                return;
            }
        }else{
           return back()->with('error', 'Oops, Something went wrong!'); 
        }
    }

    public function addElectrix($id, $meterType){
        if($meterType == 'REG'){
            $this->regtype = true;
            $this->wasactype = false;
        }elseif($meterType == 'WASAC'){
            $this->regtype = false;
            $this->wasactype = true;
        }
        $this->electrixShow();
        $this->owner = $id;
        return $this->owner;
    }

    public function electrixSave($id){
        $this->electrixOnlyStore($id);
    }

    public function activate($id){
        Clients::where('id',$id)->update([
            'account_status' => 'Active',
        ]);
        session()->flash('success', 'Account Activated!');
        return $this->mount($id);
    }

    public function suspend($id){
        Clients::where('id',$id)->update([
            'account_status' => 'Inactive',
        ]);
        session()->flash('success', 'Account Suspended!');
        return $this->mount($id);
    }

}