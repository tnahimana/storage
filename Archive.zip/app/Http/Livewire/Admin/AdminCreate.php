<?php

namespace App\Http\Livewire\Admin;

use App\Models\Cell;
use App\Models\Role;
use App\Models\User;
use App\Models\Admins;
use App\Models\Sector;
use App\Models\Address;
use App\Models\Village;
use Livewire\Component;
use App\Models\District;
use App\Models\Document;
use App\Models\Province;
use Illuminate\Support\Facades\Hash;

class AdminCreate extends Component
{
    public $firstname;
    public $middlename;
    public $lastname;
    public $email;
    public $phone;
    public $gender;
    public $document_type;
    public $document_number;
    public $password;
    public $password_confirmation;
    public $province;
    public $district;
    public $sector;
    public $cell;
    public $village;

    public function render()
    {
        return view('livewire.admin.admin-create',[
            'document' => Document::get(),
            'provinces' => Province::get(),
            'districts' => District::where('province_id', $this->province)->get(),
            'sectors' => Sector::where('district_id', $this->district)->get(),
            'cells' => Cell::where('sector_id', $this->sector)->get(),
            'villages' => Village::where('cell_id', $this->cell)->get(),
        ]);
    }

    protected $rules = [
        'firstname'=> 'required | string | min:3 ',
        'middlename'=> 'string',
        'lastname'=> 'required | string | min:3 ',
        'gender'=> 'required',
        'email'=> 'required | email | unique:users',
        'document_type'=> 'required',
        'document_number'=> 'required | min:16 | unique:admins',
        'phone'=> 'required | numeric | regex:/^([0-9\s\-\+\(\)]*)$/|min:10 | unique:admins',
        'password'=> 'required | min:8',
        'password_confirmation'=> 'required | min:8 | same:password',
        'province' => 'required',
        'district' => 'required',
        'sector' => 'required',
        'cell' => 'required',
        'village' => 'required',
    ];

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function save()
    {
        if(auth()->user()->role->name == 'super_admin'){
            $validatedData = $this->validate();
            $this->adminStore();
            $this->reset();
            return redirect('/admins')->with('success', 'Admin added Successfully!');
        }else{
            return redirect()->to('/dashboard')->with('error', 'Unauthorized Action!');
        }
    }

    public function userStore(){
        $role = Role::where('name', 'admin')->first();
        User::create([
            'username' => $this->email,
            'email' => $this->email,
            'password' => Hash::make($this->password),
            'role_id' => $role->id,
        ]);
        $user = User::where('email', $this->email)->first();
        return $user->id;
    }

    public function adddressStore(){
        if(Address::where('village_id', $this->village)->first() == null){
            Address::create([
                'province_id' => $this->province,
                'district_id' => $this->district,
                'sector_id' => $this->sector,
                'cell_id' => $this->cell,
                'village_id' => $this->village,
            ]);
        }
        $address = Address::where('village_id', $this->village)->first();
        return $address->id;
    }

    public function adminStore(){
        $user_id = $this->userStore();
        $role = Role::where('name', 'admin')->first();
        $address_id = $this->adddressStore();
        Admins::create([
            'user_id' => $user_id,
            'role_id' => $role->id,
            'firstname' => $this->firstname,
            'middlename' => $this->middlename,
            'lastname' => $this->lastname,
            'email' => $this->email,
            'phone' => $this->phone,
            'gender' => $this->gender,
            'document_id' => $this->document_type,
            'document_number' => $this->document_number,
            'address_id' => $address_id,
            'password' => Hash::make($this->password),
        ]);

        return session()->flash('success', 'Admin added Successfully!');
    }
}
