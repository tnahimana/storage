<?php

namespace App\Http\Livewire\Meter;

use Livewire\Component;
use App\Models\ElectrixMeter;
use App\Models\TokenGenerate;
use Illuminate\Support\Facades\Http;

class MeterActions extends Component
{
    public $form = false;
    public $tamper = false;
    public $credit = false;
    public $records = false;
    public $result = false;
    public $meter_number;
    public $meter_record;
    public $token;
    
    public function render()
    {
        return view('livewire.meter.meter-actions');
    }

    public function clearTamper(){
        $this->form = true;
        $this->tamper = true;
        $this->credit = false;
        $this->records = false;
        $this->result = false;
    }

    public function clearCredit(){
        $this->form = true;
        $this->credit = true;
        $this->tamper = false;
        $this->records = false;
        $this->result = false;
    } 

    public function meterRecords(){
        $this->form = true;
        $this->credit = false;
        $this->tamper = false;
        $this->records = true;
    }

    public function save(){
        if($this->tamper == true){
            $this->validateOnly('meter_number');
            try {
                $meter = Http::post('http://www.newapi.stronpower.com/api/QueryMeterInfo',[
                    "CompanyName"=> "Genius-Solutions",
                    "UserName" => "Admin84",
                    "PassWord" => "123456",
                    "MeterId" => $this->meter_number
                ])->json();
                $custmer_id = $meter[0]['Customer_id'];
                $response = Http::post('http://www.newapi.stronpower.com/api/ClearTamper',[
                    "CompanyName" => "Genius-Solutions",
                    "UserName" =>"Admin84",
                    "PassWord" => "123456",
                    "CustomerID" => $custmer_id,
                    "METER_ID" => $this->meter_number
                ]);
                $result = $response->json();
                $split = explode(',',$result);
                $this->token = $split[0];
                $electrix_id = ElectrixMeter::where('electrix_meter_number', $this->meter_number)->first();
                $this->token = str_replace(" ","-", $this->token);
                $saveGeneratedToken = TokenGenerate::create([
                    'user_id' => auth()->user()->id,
                    'electrix_meter_id' => $electrix_id->id,
                    'token' => $this->token,
                    'token_type' => 'clear_tamper-web',
                ]);
                if($saveGeneratedToken){
                    $this->result = true;
                    $this->form = false;
                    $this->credit = false;
                }
            } catch (\Throwable $th) {
                return redirect()->to('meters')->with('error', 'Oops!, Something went wrong.');
            }
        }
        if($this->credit == true){
            $this->validateOnly('meter_number');
            try {
                $meter = Http::post('http://www.newapi.stronpower.com/api/QueryMeterInfo',[
                    "CompanyName"=> "Genius-Solutions",
                    "UserName" => "Admin84",
                    "PassWord" => "123456",
                    "MeterId" => $this->meter_number
                ])->json();
                $custmer_id = $meter[0]['Customer_id'];
                $response = Http::post('http://www.newapi.stronpower.com/api/ClearCredit',[
                    "CompanyName" => "Genius-Solutions",
                    "UserName" =>"Admin84",
                    "PassWord" => "123456",
                    "CustomerID" => $custmer_id,
                    "METER_ID" => $this->meter_number
                ]);
                $result = $response->json();
                $split = explode(',',$result);
                $this->token = $split[0];
                $electrix_id = ElectrixMeter::where('electrix_meter_number', $this->meter_number)->first();
                $this->token = str_replace(" ","-", $this->token);
                $saveGeneratedToken = TokenGenerate::create([
                    'user_id' => auth()->user()->id,
                    'electrix_meter_id' => $electrix_id->id,
                    'token' => $this->token,
                    'token_type' => 'clear_credit-web',
                ]);
                if($saveGeneratedToken){
                    $this->result = true;
                    $this->form = false;
                    $this->tamper = false;
                }
            } catch (\Throwable $th) {
                return redirect()->to('meters')->with('error', 'Oops!, Something went wrong.');
            }
        }
        if($this->records == true){
            $this->validateOnly('meter_number');
            try {
                $meter = Http::post('http://www.newapi.stronpower.com/api/QueryMeterInfo',[
                    "CompanyName"=> "Genius-Solutions",
                    "UserName" => "Admin84",
                    "PassWord" => "123456",
                    "MeterId" => $this->meter_number
                ])->json();
                $this->meter_record = $meter[0];
                $this->result = true;
                $this->form = false;
                $this->tamper = false;
                $this->credit = false;
            } catch (\Throwable $th) {
                return redirect()->to('meters')->with('error', 'Oops!, Something went wrong.');
            }
        }
    }

    protected $rules = [
        'meter_number' => 'required | digits:11'
    ];

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }
}