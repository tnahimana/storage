<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSalesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sales', function (Blueprint $table) {
            $table->id();
            $table->string('initial_cost');
            $table->foreignId('reg_meter_id')->constrained()->onDelete('cascade');
            $table->foreignId('electrix_meter_id')->constrained()->onDelete('cascade');
            $table->string('token_cost')->constrained()->onDelete('cascade');
            $table->string('reg_meter_token')->constrained()->onDelete('cascade');
            $table->string('electrix_meter_token')->constrained()->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sales');
    }
}
