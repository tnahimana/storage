<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddDataKeysToAddressesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('addresses', function (Blueprint $table) {
            $table->unsignedBigInteger('province_id')->after('id');
            $table->unsignedBigInteger('district_id')->after('province_id');
            $table->unsignedBigInteger('sector_id')->after('district_id');
            $table->unsignedBigInteger('cell_id')->after('sector_id');
            $table->unsignedBigInteger('village_id')->after('cell_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('addresses', function (Blueprint $table) {
            //
        });
    }
}
