<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateElectrixMetersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('electrix_meters', function (Blueprint $table) {
            $table->id();
            $table->foreignId('reg_meter_id')->nullable()->constrained()->onDelete('cascade');
            $table->string('electrix_meter_number');
            $table->string('meter_status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('electrix_meters');
    }
}
