
<div class="flex">
    <!-- BEGIN: Content -->
    <div class="content">
        <div class="container mx-auto mt-4">
            <div class="grid lg:grid-cols-2 gap-12">
                <div wire:click="clearTamper" class="flex justify-center p-6 text-6xl bg-green-200 border-2 border-gray-300 rounded-xl">
                    <i class="fa-solid fa-unlock-keyhole mr-12"></i><br>
                    <span class="text-base font-bold">Clear Tamper</span>
                </div>
                <div wire:click="clearCredit" class="flex justify-center p-6 text-6xl bg-green-200 border-2 border-gray-300 rounded-xl">
                    <i class="fa-solid fa-credit-card mr-12 mt-2"></i> <br>
                    <span class="text-base font-bold">Clear Credit</span>
                </div>
                
            </div>
        </div>
        <div class="container mx-auto mt-6">
            <?php if($form == true): ?>
                <div class="content" id="centered">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.loading','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <div class="grid lg:grid-cols-8 gap-6 mt-3">
                        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
                            <form action="POST" wire:submit.prevent="save">
                                <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                                    <div class="intro-y flex items-center mt-6 border-b border-gray-200 dark:border-dark-5 pb-4">
                                        <h2 class="text-lg font-medium mr-auto mt-4 ml-6">
                                            <?php if($this->tamper == true): ?> Clear Tamper <?php elseif($credit == true): ?> Clear Credit <?php endif; ?>
                                        </h2>
                                    </div>

                                    <div class="intro-y box mt-5">
                                    
                                        <div id="inline-form" class="p-5">

                                            <div class="preview mr-5 ml-5">
                                                <div class="flex flex-wrap -mx-3 mb-2">
                                                    <div class="w-full md:w-full px-3 mb-6 md:mb-0">
                                                        <div class="md:mr-2">
                                                            <input id="input-state-1" wire:model="meter_number" type="text" class="form-control <?php $__errorArgs = ['meter_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Electrix Meter Number..." maxlength="11">
                                                            <?php $__errorArgs = ['meter_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div id="input-state"  class="p-5 flex flex-wrap items-end justify-end">         
                                                    <button type="submit" style="background-color: rgb(17, 17, 134)" class="btn btn-primary pl-5 pr-5 -mt-1 mr-2 -mb-2"> Fetch <div wire:loading.delay>ing... <i  data-color="white" class="fas fa-spinner fa-pulse w-4 h-4 ml-2"></i> </div> </button>
                                            </div>
                                            
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            </form>
                        </div>

                    </div>    
                </div>
            <?php endif; ?>
            <?php if($result == true): ?>
                <div class="flex justify-center rounded-xl lg:text-xl sm:text-xs">
                    <div class="content" id="center">
                        <div class="grid grid-cols-12 gap-6 mt-5">
                            <div class="intro-y col-span-12 place-items-center lg:col-span-12">
                                <div class="intro-y box mt-5 " style="border-top: 3px solid blue">

                                    <div class="intro-y flex items-center mt-6 border-b border-gray-200 dark:border-dark-5 pb-4">
                                        <h2 class="text-lg font-medium mr-auto mt-4 ml-6">
                                          <?php if($tamper == true): ?>  Electrix Meter Token <?php elseif($credit == true): ?> Electrix Meter Credit <?php endif; ?>
                                        </h2>
                                    </div>

                                    <div class="intro-y box mt-5">
                                    
                                        <div id="inline-form" class="p-5">

                                            <div class="preview sm:mr-5 sm:ml-5">
                                                <div class="intro-y box sm:px-5 pt-5 mt-1">
                                                    <div class="flex flex-col lg:flex-row border-b border-gray-200 dark:border-dark-5 pb-5 -mx-5">
                                                        <div class="flex flex-2 sm:px-5 items-center justify-center lg:justify-start">
                                                            <div class="w-40 h-40 sm:w-44 sm:h-44 flex-none lg:w-52 lg:h-52 image-fit relative">
                                                                <img alt="logo" class="rounded-full" src="<?php echo e(asset('./dist/images/electrix-login.png')); ?>">
                                                            </div>
                                                        </div>
                                                        <div id="height"  class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                                            <div class="font-medium text-center lg:text-left lg:mt-3"><?php if($tamper == true): ?> Clear Tamper Token <?php elseif($credit == true): ?> Clear Credit Token <?php endif; ?></div>
                                                            <div class="flex flex-col sm:justify-start sm:items-start lg:mt-6 sm:mt-0">
                                                                <?php if($tamper == true || $credit == true): ?>
                                                                <div class="truncate sm:whitespace-normal flex items-center lg:mt-6"> 
                                                                    <span class="ml-2 mt-5"><i class="fa-solid fa-qrcode h-3 w-4 lg:mr-2"></i><strong class="lg:mr-5 font-medium lg:text-xl sm:text-sm">Token: </strong> <span class="text-blue-700">
                                                                        <?php if($token == 'false01'): ?> Wrong Meter Number <?php else: ?> <?php echo e($token); ?> <?php endif; ?>
                                                                    </span></span>
                                                                </div>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            </div>
                        </div>    
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <!-- END: Content -->
</div><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/livewire/meter/meter-actions.blade.php ENDPATH**/ ?>