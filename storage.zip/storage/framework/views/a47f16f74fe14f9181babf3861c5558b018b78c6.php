<!-- BEGIN: Dark Mode Switcher-->

<!-- END: Dark Mode Switcher--><?php /**PATH /home/nahimana/Documents/workspace/electrix-meter/resources/views////layout/components/dark-mode-switcher.blade.php ENDPATH**/ ?>