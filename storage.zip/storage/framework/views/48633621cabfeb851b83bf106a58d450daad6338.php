<?php $__env->startSection('title'); ?>
    Register Client | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-client'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Register Client
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('client.client-create')->html();
} elseif ($_instance->childHasBeenRendered('V697SjI')) {
    $componentId = $_instance->getRenderedChildComponentId('V697SjI');
    $componentTag = $_instance->getRenderedChildComponentTagName('V697SjI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('V697SjI');
} else {
    $response = \Livewire\Livewire::mount('client.client-create');
    $html = $response->html();
    $_instance->logRenderedChild('V697SjI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/client/create.blade.php ENDPATH**/ ?>