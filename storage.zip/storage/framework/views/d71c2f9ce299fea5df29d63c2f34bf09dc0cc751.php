<?php $__env->startSection('title'); ?>
    Update Admin Info | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-admin'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Update Admin Info
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    admins/<?php echo e($id); ?>/edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.admin-update',['id' => $id])->html();
} elseif ($_instance->childHasBeenRendered('whGVxLi')) {
    $componentId = $_instance->getRenderedChildComponentId('whGVxLi');
    $componentTag = $_instance->getRenderedChildComponentTagName('whGVxLi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('whGVxLi');
} else {
    $response = \Livewire\Livewire::mount('admin.admin-update',['id' => $id]);
    $html = $response->html();
    $_instance->logRenderedChild('whGVxLi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahimana/Documents/workspace/electrix-meter/resources/views/admin/update.blade.php ENDPATH**/ ?>