<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Electrix Ltd</title>
  <meta name="keywords" content="Electrix,Smart Metering,Energy Solutions, Vending Software, Rwanda Energy">
  <meta name="author" content="Electrix Ltd">
  <meta name="description" content="Electrix Ltd is a fintech company that is specialized in developping Mobile and Web applications designed to solve problems arising in Rwandan energy sector">
  <meta name="author" content="Electrix Ltd">

  <!-- Favicons -->
  <link href="<?php echo e(asset('web/assets/img/electrix-login.png')); ?>" rel="shortcut icon">
  <link href="<?php echo e(asset('web/assets/img/electrix-login.png')); ?>" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('web/assets/vendor/aos/aos.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('web/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('web/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('web/assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('web/assets/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('web/assets/vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('web/assets/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('web/assets/css/style.css')); ?>" rel="stylesheet">
  <?php echo \Livewire\Livewire::styles(); ?>


</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="/">Electrix</a></h1>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#services">Services</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link   scrollto" href="#products">Products</a></li>
          <li><a class="nav-link scrollto" href="#team">Team</a></li>
          <li><a class="nav-link scrollto" href="/apps">App</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
          <li><a class="getstarted scrollto" href="/login" target="_blank">Sign In</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
          <h1>Pay electricity bills Now </h1>
          <h2>With our mobile app you can easily pay your electricity bills, access your energy purchase records and so much more...</h2>
          <div class="d-flex justify-content-center justify-content-lg-start">
            <a href="#cta" class="btn-get-started scrollto">Download Our App</a>
            <a href="" class="glightbox btn-watch-video"> <i class="bx bxl-play-store"></i> <i class="bx bxl-apple"></i></a>
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
          <img src="<?php echo e(asset('web/assets/img/hero-img.png')); ?>" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients section-bg">
      <div class="container">

        <div class="row" data-aos="zoom-in">

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="<?php echo e(asset('web/assets/img/partners/stron.png')); ?>" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="<?php echo e(asset('web/assets/img/partners/reg.png')); ?>" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="<?php echo e(asset('web/assets/img/partners/mtn.png')); ?>" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="<?php echo e(asset('web/assets/img/partners/bpr.png')); ?>" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="<?php echo e(asset('web/assets/img/partners/airtel.png')); ?>" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="<?php echo e(asset('web/assets/img/partners/alibaba.png')); ?>" class="img-fluid" alt="">
          </div>

        </div>

      </div>
    </section><!-- End Cliens Section -->

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>About Us</h2>
        </div>

        <div class="row content">
          <div class="col-lg-12">
            <p class="text-center">
              <strong>Electrix Ltd</strong> is a fintech company specialized in developing Internet Of Things (IOT) systems that aims to solve our daily live challenges. With our newly introduced smart energy meters we are aiming on 
              revolutionalizing the satisfaction of energy management to all Rwandans accross the country through our smart energy meters you can easily 
              takes control of your energy usage and recharge your meter at the confort of your home.
            </p>
            <div class="row content">
              <div class="col-lg-12">
                <p class="d-flex justify-content-center">
                  <box-icon type='solid' name='quote-alt-left'></box-icon> <strong>Our Solution</strong> <box-icon type='solid' name='quote-alt-right'></box-icon>
                </p>
                <ul class="d-lg-flex justify-content-center">
                  <li><i class="ri-check-double-line"></i>  No More sharing electricity bills between leeses</li>
                  <li><i class="ri-check-double-line"></i> Individual Energy purchase per leese</li>
                  <li><i class="ri-check-double-line"></i>  Flexible Recharging System</li>
                  <li><i class="ri-check-double-line"></i>  Simple and Easy recharge system</li>
                  <li><i class="ri-check-double-line"></i> Intelligent reports for your reference</li>
                </ul>
              </div>
            </div>
            
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us section-bg">
      <div class="container-fluid" data-aos="fade-up">

        <div class="row">

          <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">

            <div class="content">
              <h3><strong>Electrix Vending Software </strong></h3>
              <p>
                It features a perfect user interface that allows users to easily navigate the application and access everything that our application has to offer at your own comfort.
              </p>
            </div>

            <div class="accordion-list">
              <ul>
                <li>
                  <a data-bs-toggle="collapse" class="collapse" data-bs-target="#accordion-list-1"><span>01</span> Flexible Vending System <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-1" class="collapse show" data-bs-parent=".accordion-list">
                    <p>
                      Our vending software provides a flexible user interface designed with user satisfaction in mind, with our application you can pay energy bills, request new energy meter, access energy bills reports and so much more...  
                    </p>
                  </div>
                </li>

                <li>
                  <a data-bs-toggle="collapse" data-bs-target="#accordion-list-2" class="collapsed"><span>02</span> Mobile payment accepted <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-2" class="collapse" data-bs-parent=".accordion-list">
                    <p>
                      <strong>Supported Payment Methods</strong>
                    </p>
                    <img src="<?php echo e(asset('web/assets/img/partners/payment.png')); ?>" alt="">
                  </div>
                </li>

                <li>
                  <a data-bs-toggle="collapse" data-bs-target="#accordion-list-3" class="collapsed"><span>03</span> E-shopping <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-3" class="collapse" data-bs-parent=".accordion-list">
                    <p>
                      You can easily buy a new energy meter online and get it delivered to your home.
                    </p>
                  </div>
                </li>

                <li>
                  <a data-bs-toggle="collapse" data-bs-target="#accordion-list-4" class="collapsed"><span>04</span> Free Installation <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-4" class="collapse" data-bs-parent=".accordion-list">
                    <p>
                      After purchasing our energy meter meter, you will be assigned with a technician to install your energy meter for free.
                    </p>
                  </div>
                </li>

              </ul>
            </div>

          </div>

          <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img animated" style='background-image: url("<?php echo e(asset('web/assets/img/why-us.png')); ?>");' data-aos="zoom-in" data-aos-delay="150">&nbsp;</div>
        </div>

      </div>
    </section><!-- End Why Us Section -->

    <!-- ======= Skills Section ======= -->
    <section id="skills" class="skills">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-lg-6 d-flex align-items-center" data-aos="fade-right" data-aos-delay="100">
            <img src="<?php echo e(asset('web/assets/img/meters/202207081001079.jpeg')); ?>" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 content" data-aos="fade-left" data-aos-delay="100">
            <img src="<?php echo e(asset('web/assets/img/meters/2022070810013021.jpeg')); ?>" class="img-fluid" alt="">
          </div>
        </div>

      </div>
    </section><!-- End Skills Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
          <p>Electrix Ltd offers the best services for your business and home, Customers satisfaction is our priority.</p>
        </div>

        <div class="row">
          <div class="col-xl-3 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon">
                <img class="img-service" src="<?php echo e(asset('web/assets/img/services/web-dev.png')); ?>" alt="">
              </div>
              <h4><a href="">Web Development</a></h4>
              <p>Are you planning to design or redesign your website? Yes, we can help you in high end website development in WordPress, PHP. Further, we can help you in Domain Registration and Web Hosting.
                Our team of expert developers and designers follow current global practice while developing website for you.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon">
                <img class="img-service" src="<?php echo e(asset('web/assets/img/services/metering.png')); ?>" alt="">
              </div>
              <h4><a href="">Smart Metering</a></h4>
              <p>Are you lookng for a perfect energy solution for your home or business, We offer smart prepaid energy meters that allows you to better manage your energy consumption efficiently and effectively, our meters has an anti-tampering system which prevents anyone from tampering with your purchased energy.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon">
                <img class="img-service" src="<?php echo e(asset('web/assets/img/services/mobile-app.png')); ?>" alt="">
              </div>
              <h4><a href="">Mobile Apps</a></h4>
              <p>If you are planning to reach your customers through their phones, all you need is a mobile app. Just let us know your requirements, we will realize them.
                During development, we practice the industry standards and make sure that the app meets required standards. We can help you to develop app and submit in Play store and App Store. </p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon">
                <img class="img-service" src="<?php echo e(asset('web/assets/img/services/support.png')); ?>" alt="">
              </div>
              <h4><a href="">24/7 Help & Support</a></h4>
              <p>Our team of experts works tirelesly to offer a 24/7 help and support to our clients and helps them deal with any problem or difficulty encountered while using our systems, feel free to be in touch with us. We are here serve you at our best capacity. Electrix.</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
      <div class="container" data-aos="zoom-in">

        <div class="row">
          <div class="col-lg-7 text-center text-lg-start">
            <h3>Download  Our App Today</h3>
            <p>Electrix Vending is a newly introduced application that enables our customers to purchase recharge tokens for our smart energy meters at the confort of their homes.</p>
          </div>
          <div class="col-lg-5 cta-btn-container text-center justify-content-center">
            <a class="cta-btn align-middle bg-success" href="#"><i class="bx bxl-play-store"></i> Google Play Store</a>
            <a class="cta-btn align-middle bg-dark" href="#"><i class="bx bxl-apple"></i> IOS App Store</a>
          </div>
        </div>

      </div>
    </section><!-- End Cta Section -->

    <!-- End Portfolio Section -->

    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Our Team</h2>
          <!-- <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p> -->
        </div>

        <div class="row">

          <div class="col-lg-4">
            <div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="100">
              <div class="pic"><img src="<?php echo e(asset('web/assets/img/team/harris.jpg')); ?>" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Nahimana Theoneste</h4>
                <span>Chief Executive Officer</span>
                <!-- <p>Explicabo vol</p> -->
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0">
            <div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="200">
              <div class="pic"><img src="<?php echo e(asset('web/assets/img/team/149071.png')); ?>" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Mugisha Allain</h4>
                <p class="text-white">-</p>
                <span>Marketing Manager</span>
                <!-- <p>Aut maiores voluptates amet et quis praesentium qui senda para</p> -->
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0">
            <div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="200">
              <div class="pic"><img src="<?php echo e(asset('web/assets/img/team/149071.png')); ?>" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Niyomugabo Jean Paul</h4>
                <p class="text-white">-</p>
                <span>Product Manager</span>
                <!-- <p>Aut maiores voluptates amet et quis praesentium qui senda para</p> -->
                <div class="social mb-2">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Team Section -->

    <!-- ======= Pricing Section ======= -->
    <section id="products" class="pricing">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Pricing</h2>
          STE18-B is an STS Standard compliant, keypad type, automatically connection or disconnection prepaid smart electricity meter. It can be top up with Stronpay vending software directly and communicate with AMI system via LoRa-RF module.
        </div>

        <div class="row">

          <div class="col-lg-5" data-aos="fade-up" data-aos-delay="100">
            <div class="box">
              <img src="<?php echo e(asset('web/assets/img/meters/single-phase-meter.png')); ?>" alt="">
            </div>
          </div>

          <div class="col-lg-7 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="200">
            <div class="box featured">
              <h3>New Type STE18-B Single Phase Energy Meter on the shelves!</h3>
              <h4><sup>$</sup>55 <span>Electrical Parameters</span></h4>
              <ul>
                <li><i class="bx bx-check"></i> Nominal Voltage: 230V</li>
                <li><i class="bx bx-check"></i> Working Voltage Range: 70%~120%Un</li>
                <li><i class="bx bx-check"></i> Nominal Frequency: 50-60Hz</li>
                <li><i class="bx bx-check"></i> Basic Current (Ib): 5A</li>
                <li><i class="bx bx-check"></i> Maximum Current (Imax): 80A</li>
                <li><i class="bx bx-check"></i> Starting Current (Ist): 20mA</li>
                <li><i class="bx bx-check"></i> Active Energy Constant: 1000imp/kWh</li>
                <li><i class="bx bx-check"></i> Power Consumption in Voltage Circuit: <2W  <8VA </li>
                  <li><i class="bx bx-check"></i> Power Consumption in Current Circuit: <1VA </li>
                  <li><i class="bx bx-check"></i> Operation Temperature Range: -25℃-70℃ </li>
                    <li><i class="bx bx-check"></i> Storage Temperature Range: -40℃-85℃ </li>
              </ul>
              <a href="#" class="buy-btn">Buy</a>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Pricing Section -->

    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Frequently Asked Questions</h2>
        </div>

        <div class="faq-list">
          <ul>
            <li data-aos="fade-up" data-aos-delay="100">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" class="collapse" data-bs-target="#faq-list-1">What is the requirements to obtain electrix energy meter? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-1" class="collapse show" data-bs-parent=".faq-list">
                <p>
                  You need to pay $55 per meter and provide a copy of land documents along with REG energy meter number to be shared with our meters.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="200">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-2" class="collapsed">How long it takes to install electrix energy meter to my home? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-2" class="collapse" data-bs-parent=".faq-list">
                <p>
                  Your energy meter meter will be installed on the same day you made a purchase at free of charge.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="300">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-3" class="collapsed">How to recharge electrix energy meter? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-3" class="collapse" data-bs-parent=".faq-list">
                <p>
                  Electrix energy meter is recharged by a 20 digits token that is generated after purchasing electricity on our mobile application.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="400">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-4" class="collapsed">What can i do when my energy meter gets locked? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-4" class="collapse" data-bs-parent=".faq-list">
                <p>
                  Contact us on +250785257667 or email us on support@electrix.com and will provide you a reset code to unlock your meter.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="500">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-5" class="collapsed"> What is the guarantee of your energy meters? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-5" class="collapse" data-bs-parent=".faq-list">
                <p>
                  We provide 5 years waranty for our energy meters and we continue to provide support after the given waranty expires.
                </p>
              </div>
            </li>

          </ul>
        </div>

      </div>
    </section><!-- End Frequently Asked Questions Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contact</h2>
          <p>For any enquiry about our products or services, Feel free to contact us and our team will get back to you as soon as possible.</p>
        </div>

        <div class="row">

          <div class="col-lg-5 d-flex align-items-stretch">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Location:</h4>
                <p>KN 82 Street, Kigali, Rwanda</p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p>info@electrix.rw</p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Call:</h4>
                <p>+250 785 257 667</p>
              </div>

              <iframe src="https://maps.google.com/maps?q=kigali,%20kn%2082%20st,%20&t=&z=15&ie=UTF8&iwloc=&output=embed" frameborder="0" style="border:0; width: 100%; height: 290px;" allowfullscreen></iframe>
            </div>

          </div>

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contact.contact')->html();
} elseif ($_instance->childHasBeenRendered('DNvGBvf')) {
    $componentId = $_instance->getRenderedChildComponentId('DNvGBvf');
    $componentTag = $_instance->getRenderedChildComponentTagName('DNvGBvf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DNvGBvf');
} else {
    $response = \Livewire\Livewire::mount('contact.contact');
    $html = $response->html();
    $_instance->logRenderedChild('DNvGBvf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
          
        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-newsletter">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6">
            <h4>Join Our Newsletter</h4>
            <p>Get notified for new product updates and available promotions on daily basis.</p>
            <form action="/subscribe" method="post">
              <input type="email" name="email"><input disabled type="submit" value="Subscribe" onclick="this.disabled=true;this.value='Sending, please wait...';this.form.submit();">
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Electrix</h3>
            <p>
              KN  82 Street <br>
              Nyarugenge, Kigali<br>
              Rwanda <br>
              <strong>Phone:</strong> +250 785 257 667<br>
              <strong>Email:</strong> info@electrix.rw<br>
            </p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#hero">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#about">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#products">Products</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Development</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Smart Metering</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Mobile Apps</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">24/7 Help & Support</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Social Networks</h4>
            <p>Follow us on our social media platforms</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-youtube"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container footer-bottom clearfix">
      <div class="copyright">
        &copy; Copyright <strong><span>Electrix Ltd</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/ -->
        &copy; Inc <a href="/"><?php if(date('Y') > 2022): ?> 2022 - <?php echo e(date('Y')); ?> <?php else: ?> <?php echo e(date('Y')); ?> <?php endif; ?></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('web/assets/vendor/aos/aos.js')); ?>"></script>
  <script src="<?php echo e(asset('web/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('web/assets/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
  <script src="<?php echo e(asset('web/assets/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('web/assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('web/assets/vendor/waypoints/noframework.waypoints.js')); ?>"></script>
  <script src="<?php echo e(asset('web/assets/vendor/php-email-form/validate.js')); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('web/assets/js/main.js')); ?>"></script>
  <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
  <?php echo \Livewire\Livewire::scripts(); ?>


</body>

</html><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/home/index.blade.php ENDPATH**/ ?>