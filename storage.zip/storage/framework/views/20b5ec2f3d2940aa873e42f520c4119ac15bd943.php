<?php $__env->startSection('title'); ?>
   App Release Versions | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-shortcode'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
App Release Versions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    updates
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('shortcode.shortcode-index')->html();
} elseif ($_instance->childHasBeenRendered('fV0hoS4')) {
    $componentId = $_instance->getRenderedChildComponentId('fV0hoS4');
    $componentTag = $_instance->getRenderedChildComponentTagName('fV0hoS4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fV0hoS4');
} else {
    $response = \Livewire\Livewire::mount('shortcode.shortcode-index');
    $html = $response->html();
    $_instance->logRenderedChild('fV0hoS4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/shortcode/index.blade.php ENDPATH**/ ?>