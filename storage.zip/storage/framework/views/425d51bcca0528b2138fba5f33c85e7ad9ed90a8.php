<?php $__env->startSection('title'); ?>
    Update Agent Info | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-agent'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Update Agent Info
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    agents/<?php echo e($agent); ?>/edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('agent.agent-update',['id' => $agent])->html();
} elseif ($_instance->childHasBeenRendered('aZ78Kny')) {
    $componentId = $_instance->getRenderedChildComponentId('aZ78Kny');
    $componentTag = $_instance->getRenderedChildComponentTagName('aZ78Kny');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('aZ78Kny');
} else {
    $response = \Livewire\Livewire::mount('agent.agent-update',['id' => $agent]);
    $html = $response->html();
    $_instance->logRenderedChild('aZ78Kny', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahimana/Documents/workspace/electrix-meter/resources/views/agent/update.blade.php ENDPATH**/ ?>