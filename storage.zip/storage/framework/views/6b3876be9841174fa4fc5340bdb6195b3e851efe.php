<?php $__env->startSection('title'); ?>
    Update Shortcode | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-shortcode'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Update Shortcode
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    <?php echo e($update->id); ?>/edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('shortcode.shortcode-update',[ 'update' => $update ])->html();
} elseif ($_instance->childHasBeenRendered('zC0qz2F')) {
    $componentId = $_instance->getRenderedChildComponentId('zC0qz2F');
    $componentTag = $_instance->getRenderedChildComponentTagName('zC0qz2F');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zC0qz2F');
} else {
    $response = \Livewire\Livewire::mount('shortcode.shortcode-update',[ 'update' => $update ]);
    $html = $response->html();
    $_instance->logRenderedChild('zC0qz2F', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/shortcode/show.blade.php ENDPATH**/ ?>