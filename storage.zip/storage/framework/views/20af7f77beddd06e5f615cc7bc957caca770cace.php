<?php $__env->startSection('title'); ?>
    Agent Info | Electrix Vending
<?php $__env->stopSection(); ?>
<?php $__env->startSection('active-agent'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Agent Info
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    agents/<?php echo e($agent); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-agent'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('agent.agent-show', ['id' => $agent])->html();
} elseif ($_instance->childHasBeenRendered('ywIqMro')) {
    $componentId = $_instance->getRenderedChildComponentId('ywIqMro');
    $componentTag = $_instance->getRenderedChildComponentTagName('ywIqMro');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ywIqMro');
} else {
    $response = \Livewire\Livewire::mount('agent.agent-show', ['id' => $agent]);
    $html = $response->html();
    $_instance->logRenderedChild('ywIqMro', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/agent/show.blade.php ENDPATH**/ ?>