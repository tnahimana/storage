<div class="content" id="center">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.loading','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
            <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                <div class="intro-y flex items-center mt-6 border-b border-gray-200 dark:border-dark-5 pb-4">
                    <h2 class="text-lg font-medium mr-auto mt-4 ml-6">Agent Information</h2>
                    <div class="mt-3 hidden md:block mr-6">
                        <?php if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin'): ?>
                            <div class="preview">
                                <?php if($agent->account_status == 'Inactive'): ?>
                                <button wire:click="activate(<?php echo e($agent->id); ?>)" type="button" style="background-color: green" class="btn btn-rounded-success w-24 mr-1 mb-2">Activate</button>
                                <?php elseif($agent->account_status == 'Active'): ?>
                                <button wire:click="suspend(<?php echo e($agent->id); ?>)" type="button" style="background-color: red" class="btn btn-rounded-danger w-24 mr-1 mb-2">Suspend</button>
                                <?php endif; ?>
                                <?php if($mobile_role != ""): ?>
                                    <?php if($mobile_role->extra_role == 'blocked'): ?>
                                        <button wire:click="allowApp()" type="button" style="background-color: blue" class="btn btn-rounded-danger w-24 mr-1 mb-2">Allow App</button>
                                    <?php else: ?>
                                        <button wire:click="blockApp()" type="button" style="background-color: orange" class="btn btn-rounded-danger w-24 mr-1 mb-2">Suspend App</button>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <a href="/agents/<?php echo e($agent->id); ?>/edit" class="btn btn-rounded-primary w-24 mr-1 mb-2">Update</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="intro-y box mt-5">
                
                    <div id="inline-form" class="p-5">

                        <div class="preview sm:mr-5 sm:ml-5">
                            <div class="intro-y box sm:px-5 pt-5 mt-1">
                                <div class="flex flex-col lg:flex-row border-b border-gray-200 dark:border-dark-5 pb-5 -mx-5">
                                    <div class="flex flex-2 sm:px-5 items-center justify-center lg:justify-start">
                                        <?php if($showImage): ?>
                                            <form action="POST" wire:submit.prevent="upload(<?php echo e($agent->id); ?>)">
                                                <div class="intro-y box -mt-1" style="border-top: 2px solid blue">

                                                    <div class="intro-y flex items-center border-b border-gray-200 dark:border-dark-5 pb-4">
                                                        <h2 class="text-sm font-medium mr-auto mt-4 ml-6">Update Profile</h2>
                                                    </div>

                                                    <div id="inline-form" class="p-5">

                                                            <div class="w-full md:w-full px-3 mb-0 md:mb-0">
                                                                <div class="w-full md:w-full" wire:loading> 
                                                                    <div class="alert alert-success-soft show flex items-center mb-2 w-full" role="alert" wire:target="image" wire:loading>
                                                                        <i class="fas fa-spinner w-6 h-3 mr-2"></i> Uploading...
                                                                    </div>
                                                                </div>
                                                                <div class="md:mr-2">
                                                                    <?php if(!$image): ?>
                                                                    <input id="input-state-1" wire:model="image" type="file" class="form-control" placeholder="image..." accept="image/*">
                                                                    <?php elseif($image): ?>
                                                                    <div class="w-20 h-20 sm:w-24 sm:h-24 flex-none lg:w-32 lg:h-32 image-fit relative">
                                                                        <img alt="<?php echo e($agent->fistname); ?>"  class="rounded-full" src="<?php echo e($image->temporaryUrl()); ?>">
                                                                        <?php if(!$showImage): ?>
                                                                            <div wire:click="addImage" class="absolute mb-1 mr-1 flex items-center justify-center bottom-0 right-0 bg-theme-1 rounded-full p-2"> <i class="w-4 h-3 text-white fas fa-camera"></i> </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <?php endif; ?>
                                                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>

                                                        <div id="input-state"  class="p-3 flex flex-wrap items-end justify-end">
                                                            <button wire:click="resetImage" type="button" style="background-color: red" class="btn btn-rounded-danger w-20 mt-3 pr-4 pl-4 mr-2">Reset</button>
                                                            <button type="submit" style="background-color: rgb(17, 17, 134)" class="btn btn-rounded-primary w-20 mt-3 pr-4 pl-4">upload <div wire:loading.delay>ing... <i class="fas fa-spinner fa-spin"></i></div></button>
                                                        </div>
                                                        
                                                    </div>
                                                        
                                                </div>
                                            </form>
                                        <?php else: ?>
                                            <div class="w-20 h-20 sm:w-24 sm:h-24 flex-none lg:w-32 lg:h-32 image-fit relative">
                                                <img alt="<?php echo e($agent->fistname); ?>" class="rounded-full" src="<?php if($agent->image_id != null): ?> <?php echo e(asset($agent->image->img_url)); ?> <?php else: ?> <?php echo e(asset('dist/images/profile-4.jpg')); ?> <?php endif; ?>">
                                                <?php if(!$showImage): ?>
                                                    <?php if(auth()->user()->id == $agent->id): ?>
                                                        <div wire:click="addImage" class="absolute mb-1 mr-1 flex items-center justify-center bottom-0 right-0 bg-theme-1 rounded-full p-2"> <i class="w-4 h-3 text-white fas fa-camera"></i> </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                            <div class="ml-5">
                                                <div class="w-24 sm:w-40 truncate sm:whitespace-normal font-medium text-lg"><?php echo e($agent->firstname); ?></div>
                                                <div class="text-gray-600 capitalize font-medium"><?php echo e($agent->role->name); ?></div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php if($personalInfo): ?>
                                        <div id="height"  class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Personal Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="truncate sm:whitespace-normal flex items-center"> 
                                                    <i class="fas fa-user h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">First Name:</strong><?php echo e($agent->firstname); ?></span>
                                                </div>
                                                <?php if($agent->middlename): ?>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-user h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Middle Name:</strong><?php echo e($agent->middlename); ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-user h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Last Name:</strong><?php echo e($agent->lastname); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-id-card h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium"><?php echo e($agent->document->document_type . " "); ?>Number:</strong><?php echo e($agent->document_number); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-venus-mars h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Gender:</strong><?php echo e($agent->gender); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php elseif($contactInfo): ?>
                                        <div id="height" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Contact Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="truncate sm:whitespace-normal flex items-center"> 
                                                    <i class="fas fa-envelope h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Email:</strong><?php echo e($agent->email); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-phone-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Phone:</strong><?php echo e($agent->phone); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marked-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Agent Zone:</strong><?php echo e($agent->agent_location); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php elseif($addressInfo): ?>
                                        <div id="height" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Address Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="truncate sm:whitespace-normal flex mt-2 mb-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Office Address:</strong><?php echo e($agent->address->office_address); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Province:</strong><?php echo e($agent->address->province->province); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">District:</strong><?php echo e($agent->address->district->district); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Sector:</strong><?php echo e($agent->address->sector->sector); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Cell:</strong><?php echo e($agent->address->cell->cell); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Village:</strong><?php echo e($agent->address->village->village); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="nav nav-tabs flex-col sm:flex-row justify-center lg:justify-start" role="tablist"> 
                                    <button wire:click="personalInfo" type="button" id="dashboard-tab" data-toggle="tab" data-target="#dashboard" class="py-4 sm:mr-8 <?php if($personalInfo): ?> active <?php endif; ?>" role="tab" aria-controls="dashboard" aria-selected="true">Personal Info</button> 
                                    <button wire:click="contactInfo" type="button" id="account-and-profile-tab" data-toggle="tab" data-target="#account-and-profile" class="py-4 sm:mr-8 <?php if($contactInfo): ?> active <?php endif; ?>" role="tab" aria-selected="false">Contact Info</button> 
                                    <button wire:click="addressInfo" type="button" id="activities-tab" data-toggle="tab" data-target="#activities" class="py-4 sm:mr-8 <?php if($addressInfo): ?> active <?php endif; ?>" role="tab" aria-selected="false">Address Info</button> 
                                    <div class="mt-3 flex justify-center" id="hide">
                                        <?php if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin'): ?>
                                            <div class="preview">
                                                <?php if($agent->account_status == 'Inactive'): ?>
                                                <button wire:click="activate(<?php echo e($agent->id); ?>)" type="button" style="background-color: green; hover:border: 1px solid white" class="btn btn-rounded-success w-24 mr-1 mb-2">Activate</button>
                                                <?php elseif($agent->account_status == 'Active'): ?>
                                                <button wire:click="suspend(<?php echo e($agent->id); ?>)" type="button" style="background-color: red; hover:border: 1px solid white" class="btn btn-rounded-danger w-24 mr-1 mb-2">Suspend</button>
                                                <?php endif; ?>
                                                <a href="/agents/<?php echo e($agent->id); ?>/edit" tyle="hover:border: 1px solid white" class="btn btn-rounded-primary w-24 mr-1 mb-2">Update</a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
        </div>
    </div>    
</div><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/livewire/agent/agent-show.blade.php ENDPATH**/ ?>