<?php $__env->startSection('title'); ?>
    Register Admin | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-admin'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Register Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.admin-create')->html();
} elseif ($_instance->childHasBeenRendered('dSEGw0l')) {
    $componentId = $_instance->getRenderedChildComponentId('dSEGw0l');
    $componentTag = $_instance->getRenderedChildComponentTagName('dSEGw0l');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dSEGw0l');
} else {
    $response = \Livewire\Livewire::mount('admin.admin-create');
    $html = $response->html();
    $_instance->logRenderedChild('dSEGw0l', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/admin/create.blade.php ENDPATH**/ ?>