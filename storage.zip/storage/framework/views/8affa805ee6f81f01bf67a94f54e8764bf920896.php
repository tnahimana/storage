<script src="https://cdn.tailwindcss.com"></script>
<style>
    .toast{
        animation: toast .5s forwards;
    }
    @keyframes  toast{
        from{
            opacity: 0;
            transform: translateX(100px);
            
        }
        to{
            opacity: 1;
            transform: translateX(0);
        }
    }
    .z-index{
        z-index: 999999;
    }
</style>
<div class="absolute right-0 top-15 m-5 toast">
    
    <div class="flex items-center bg-green-500 border-l-4 border-green-700 py-2 px-3 shadow-md mb-2 z-index">
        <div class="text-green-500 rounded-full bg-white mr-2 px-1 py-1">    
            <i class="fas fa-check w-4 h-3"></i>
        </div>
        <h2 class="text-white max-w-xs">
            sucess massage!
        </h2>
    </div>
    
    <div  class="flex items-center bg-red-500 border-l-4 border-red-700 py-2 px-3 shadow-md mb-2">
        <div class="text-red-500 rounded-full bg-white mr-2 px-1 py-1">    
            <i class="fas fa-check w-4 h-3"></i>
        </div>
        <h2 class="text-white max-w-xs">
            sucess massage!
        </h2>
    </div>
</div>
<script>
    $(document).ready(function () {
        $(".toast").pause(5000).fadeOut();
    });
</script><?php /**PATH /home/nahimana/Documents/workspace/electrix-meter/resources/views/components/toast-notification.blade.php ENDPATH**/ ?>