<?php $__env->startSection('title'); ?>
    Client Info | Electrix Vending
<?php $__env->stopSection(); ?>
<?php $__env->startSection('active-client'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Client Info
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    <?php echo e($client->id); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-client'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('client.client-show', ['id' => $client->id])->html();
} elseif ($_instance->childHasBeenRendered('AskWay6')) {
    $componentId = $_instance->getRenderedChildComponentId('AskWay6');
    $componentTag = $_instance->getRenderedChildComponentTagName('AskWay6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AskWay6');
} else {
    $response = \Livewire\Livewire::mount('client.client-show', ['id' => $client->id]);
    $html = $response->html();
    $_instance->logRenderedChild('AskWay6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahimana/Documents/workspace/electrix-meter/resources/views/client/show.blade.php ENDPATH**/ ?>