<div class="container mt-2">
    <div class="row align-self-center">
        <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
        <div class="login-brand">
            <img src="../assets/img/electrix-logo-top.png" style="background-color: white" alt="logo" width="100" class="shadow-light rounded-circle">
        </div>

        <div class="card card-primary rounded-lg">
            <div class="card-header"><h4>Login</h4></div>

            <div class="card-body mt--2">
            <?php if(session('error')): ?>
                <div class=" card card-danger">
                <div class="card-header">
                    <div class="btn alert-danger col-12">
                    <?php echo e(session('error')); ?>

                    </div>
                </div>
                </div>
            <?php endif; ?>
            <form wire:submit.prevent="login" class="needs-validation" novalidate="">
                <div class="form-group">
                <label for="email">Email</label>
                <input id="email" type="email" class="form-control" wire:model="email" tabindex="1" required autofocus>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger">
                        Please fill in your email
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                <div class="d-block">
                    <label for="password" class="control-label">Password</label>
                    <div class="float-right">
                    <a href="auth-forgot-password.html" class="text-small">
                        Forgot Password?
                    </a>
                    </div>
                </div>
                <input id="password" type="password" class="form-control" wire:model="password" tabindex="2" required>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger">
                        please fill in your password
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" wire:model="remember" class="custom-control-input" tabindex="3" id="remember-me">
                    <label class="custom-control-label" for="remember-me">Remember Me</label>
                </div>
                </div>

                <div class="form-group">
                <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="4">
                    Login
                </button>
                </div>
            </form>

            </div>
        </div>
        </div>
    </div>
</div>
<?php /**PATH /home/nahimana/Documents/workspace/electrix-meter/resources/views/livewire/auth/login.blade.php ENDPATH**/ ?>