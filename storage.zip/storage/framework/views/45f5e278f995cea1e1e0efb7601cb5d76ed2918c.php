<?php $__env->startSection('subhead'); ?>
    <title>Accordion - Rubick - Tailwind HTML Admin Template</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <div>Admins Register</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahimana/Documents/workspace/midonelaravel/rubick_laravel/resources/views/admin/create.blade.php ENDPATH**/ ?>