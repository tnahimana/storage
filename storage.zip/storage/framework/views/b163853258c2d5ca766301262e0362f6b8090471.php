<?php $__env->startSection('title'); ?>
    Admins | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-admin'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Admins
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    admins
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.admin-index')->html();
} elseif ($_instance->childHasBeenRendered('yb37zeq')) {
    $componentId = $_instance->getRenderedChildComponentId('yb37zeq');
    $componentTag = $_instance->getRenderedChildComponentTagName('yb37zeq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yb37zeq');
} else {
    $response = \Livewire\Livewire::mount('admin.admin-index');
    $html = $response->html();
    $_instance->logRenderedChild('yb37zeq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahimana/Documents/workspace/electrix-meter/resources/views/admin/index.blade.php ENDPATH**/ ?>