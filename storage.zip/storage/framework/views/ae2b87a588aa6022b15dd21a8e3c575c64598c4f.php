<?php $__env->startSection('body'); ?>
    <body class="main">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.loading-indicator','data' => []]); ?>
<?php $component->withName('loading-indicator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('../layout/components/dark-mode-switcher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- BEGIN: JS Assets-->
        <script src="https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js"></script>
        <script src="https://maps.googleapis.com/maps/api/js?key=["your-google-map-api"]&libraries=places"></script>
        <script src="<?php echo e(mix('dist/js/app.js')); ?>"></script>
        
        <script src="<?php echo e(asset('dist/js/toast.js')); ?>"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        
        <script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
        
        <?php echo \Livewire\Livewire::scripts(); ?>

        <!-- END: JS Assets-->

            <?php if(session()->has('success')): ?>
                <script>
                        toastr.success("<?php echo e(session('success')); ?>").fadeOut(15000);
                </script>
            <?php endif; ?>
            <?php if(session()->has('error')): ?>
                <script>
                        toastr.error("<?php echo e(session('error')); ?>").fadeOut(15000);
                </script>
            <?php endif; ?>
            <script>
                $(document).ready(function(){
                    toastr.options = {
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                    }
                    window.addEventListener('hide-form', event => {
                        $('#showmyModal').modal('hide');
                        $('#updatemyModal').modal('hide');
                        $('.modal-backdrop').remove();
                        toast.success(event.detail.message, 'success!');
                    })
                    window.addEventListener('show-form', event => {
                        toast.success(event.detail.message, 'error!');
                        $('.modal-backdrop').remove();
                    })
                })
            </script>
            <script>
                var loader = document.getElementById('preloader');
                window.addEventListener('load', function(){
                    loader.style.display = 'none';
                })
            </script>
            <script>
                var loader = document.getElementById('loader');
                window.addEventListener('load', function(){
                    loader.style.display = 'none';
                })
            </script>
            
            


        <?php echo $__env->yieldContent('script'); ?>
    </body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahimana/Documents/workspace/electrix-meter/resources/views////layout/main.blade.php ENDPATH**/ ?>