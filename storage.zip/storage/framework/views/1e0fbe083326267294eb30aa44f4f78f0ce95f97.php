
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <link href="dist/images/logo.svg" rel="shortcut icon">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Electrix Vending System">
    <meta name="keywords" content="Electrix,Smart Metering,Energy Solutions, Vending Software, Rwanda Energy">
    <meta name="author" content="Harris Technologies Ltd">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('components.loginStyle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
  <div id="app">
    <section class="section">
      <?php echo $__env->yieldContent('content'); ?>
    </section>
  </div>

  <!-- JS Libraies -->
  <?php echo $__env->make('components.loginScript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo \Livewire\Livewire::scripts(); ?>

  <!-- Page Specific JS File -->
</body>
</html>
<?php /**PATH /home/nahimana/Documents/workspace/electrix-meter/resources/views/layouts/login.blade.php ENDPATH**/ ?>