<?php $__env->startSection('title'); ?>
    Admin Info | Electrix Vending
<?php $__env->stopSection(); ?>
<?php $__env->startSection('active'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Admin Info
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    admins/<?php echo e($admin->id); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-admin'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.admin-show', ['id' => $admin->id])->html();
} elseif ($_instance->childHasBeenRendered('7B2XJ1f')) {
    $componentId = $_instance->getRenderedChildComponentId('7B2XJ1f');
    $componentTag = $_instance->getRenderedChildComponentTagName('7B2XJ1f');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7B2XJ1f');
} else {
    $response = \Livewire\Livewire::mount('admin.admin-show', ['id' => $admin->id]);
    $html = $response->html();
    $_instance->logRenderedChild('7B2XJ1f', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/admin/show.blade.php ENDPATH**/ ?>