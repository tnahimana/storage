<!-- BEGIN: Mobile Menu -->
<div class="mobile-menu md:hidden">
    <div class="mobile-menu-bar">
        <a href="" class="flex mr-auto">
            <img alt="Rubick Tailwind HTML Admin Template" class="w-6" src="<?php echo e(asset('dist/images/logo.svg')); ?>">
        </a>
        <a href="javascript:;" id="mobile-menu-toggler">
            <i data-feather="bar-chart-2" class="w-8 h-8 text-white transform -rotate-90"></i>
        </a>
    </div>
    <ul class="border-t border-theme-29 py-5 hidden">
        
    </ul>
</div>
<!-- END: Mobile Menu -->
<?php /**PATH /home/nahimana/Documents/workspace/midonelaravel/rubick_laravel/resources/views////layout/components/mobile-menu.blade.php ENDPATH**/ ?>