<?php if($showClient): ?>
<div class="content" id="center">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.loading','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
            <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                <div class="intro-y flex items-center mt-6 border-b border-gray-200 dark:border-dark-5 pb-4">
                    <h2 class="text-lg font-medium mr-auto mt-4 ml-6">Client Information</h2>
                    <div class="mt-3 hidden md:block mr-6">
                        <?php if(auth()->user()->role->name != 'client'): ?>
                            <div class="preview">
                                <?php if(auth()->user()->role->name == 'super_admin' || auth()->user()->role->name == 'admin'): ?>
                                    <?php if($client->account_status == 'Inactive'): ?>
                                    <button wire:click="activate(<?php echo e($client->id); ?>)" type="button" style="background-color: green; hover:border: 1px solid white" class="btn btn-rounded-success w-24 mr-1 mb-2">Activate</button>
                                    <?php elseif($client->account_status == 'Active'): ?>
                                    <button wire:click="suspend(<?php echo e($client->id); ?>)" type="button" style="background-color: red; hover:border: 1px solid white" class="btn btn-rounded-danger w-24 mr-1 mb-2">Suspend</button>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <button wire:click="addMeter(<?php echo e($client->id); ?>)" type="button" style="background-color: rgb(17, 17, 134)" class="btn btn-rounded-primary w-50 mr-1 mb-2 ml-2"><i class="fas fa-plus mr-2 w-4 h-3"></i> ADD Meter</button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="intro-y box mt-5">
                
                    <div id="inline-form" class="p-5">

                        <div class="preview sm:mr-5 sm:ml-5">
                            <div class="intro-y box sm:px-5 pt-5 mt-1">
                                <div class="flex flex-col lg:flex-row border-b border-gray-200 dark:border-dark-5 pb-5 -mx-5">
                                    <div class="flex flex-2 sm:px-5 items-center justify-center lg:justify-start">
                                        <?php if($showImage): ?>
                                            <form action="POST" wire:submit.prevent="upload(<?php echo e($client->id); ?>)">
                                                <div class="intro-y box -mt-1" style="border-top: 2px solid blue">

                                                    <div class="intro-y flex items-center border-b border-gray-200 dark:border-dark-5 pb-4">
                                                        <h2 class="text-sm font-medium mr-auto mt-4 ml-6">Update Profile</h2>
                                                    </div>

                                                    <div id="inline-form" class="p-5">

                                                            <div class="w-full md:w-full px-3 mb-0 md:mb-0">
                                                                <div class="w-full md:w-full" wire:loading> 
                                                                    <div class="alert alert-success-soft show flex items-center mb-2 w-full" role="alert" wire:target="image" wire:loading>
                                                                        <i class="fas fa-spinner w-6 h-3 mr-2"></i> Uploading...
                                                                    </div>
                                                                </div>
                                                                <div class="md:mr-2">
                                                                    <?php if(!$image): ?>
                                                                    <input id="input-state-1" wire:model="image" type="file" class="form-control" placeholder="image..." accept="image/*">
                                                                    <?php elseif($image): ?>
                                                                    <div class="w-20 h-20 sm:w-24 sm:h-24 flex-none lg:w-32 lg:h-32 image-fit relative">
                                                                        <img alt="<?php echo e($client->firstname); ?>"  class="rounded-full" src="<?php echo e($image->temporaryUrl()); ?>">
                                                                        <?php if(!$showImage): ?>
                                                                            <?php if(auth()->user()->id == $client->id): ?>
                                                                                <div wire:click="addImage" class="absolute mb-1 mr-1 flex items-center justify-center bottom-0 right-0 bg-theme-1 rounded-full p-2"> <i class="w-4 h-3 text-white fas fa-camera"></i> </div>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <?php endif; ?>
                                                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>

                                                        <div id="input-state"  class="p-3 flex flex-wrap items-end justify-end">
                                                            <button wire:click="resetImage" style="background-color: red" type="button" class="btn btn-rounded-danger w-24 mt-3 pr-4 pl-4 mr-2">Reset</button>
                                                            <button type="submit" style="background-color: rgb(17, 17, 134)" class="btn btn-rounded-primary w-24 mt-3 pr-4 pl-4">upload <div wire:loading.delay>ing... <i class="fas fa-spinner fa-spin"></i></div></button>
                                                        </div>
                                                        
                                                    </div>
                                                        
                                                </div>
                                            </form>
                                        <?php else: ?>
                                            <div class="w-20 h-20 sm:w-24 sm:h-24 flex-none lg:w-32 lg:h-32 image-fit relative">
                                                <img alt="<?php echo e($client->firstname); ?>" class="rounded-full" src="<?php if($client->image_id != null): ?> <?php echo e(asset($client->image->img_url)); ?> <?php else: ?> <?php echo e(asset('dist/images/profile-4.jpg')); ?> <?php endif; ?>">
                                                <?php if(!$showImage): ?>
                                                    <?php if(auth()->user()->id == $client->id): ?>
                                                        <div wire:click="addImage" class="absolute mb-1 mr-1 flex items-center justify-center bottom-0 right-0 bg-theme-1 rounded-full p-2"> <i class="w-4 h-3 text-white fas fa-camera"></i> </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                            <div class="ml-5">
                                                <div class="w-24 sm:w-40 truncate sm:whitespace-normal font-medium text-lg"><?php echo e($client->firstname); ?></div>
                                                <div class="text-gray-600 capitalize font-medium"><?php echo e($client->role->name); ?></div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php if($personalInfo): ?>
                                        <div id="height"  class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Personal Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="truncate sm:whitespace-normal flex items-center"> 
                                                    <i class="fas fa-user h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">First Name:</strong><?php echo e($client->firstname); ?></span>
                                                </div>
                                                <?php if($client->middlename): ?>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-user h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Middle Name:</strong><?php echo e($client->middlename); ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-user h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Last Name:</strong><?php echo e($client->lastname); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-id-card h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium"><?php echo e($client->document->document_type . " "); ?>Number:</strong><?php echo e($client->document_number); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-venus-mars h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Gender:</strong><?php echo e($client->gender); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php elseif($contactInfo): ?>
                                        <div id="height" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Contact Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="truncate sm:whitespace-normal flex items-center"> 
                                                    <i class="fas fa-envelope h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Email:</strong><?php echo e($client->email); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-phone-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Phone:</strong><?php echo e($client->phone); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php elseif($addressInfo): ?>
                                        <div id="height" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Address Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="truncate sm:whitespace-normal flex mt-2 mb-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Office Address:</strong><?php echo e($client->address->office_address); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Province:</strong><?php echo e($client->address->province->province); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">District:</strong><?php echo e($client->address->district->district); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Sector:</strong><?php echo e($client->address->sector->sector); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Cell:</strong><?php echo e($client->address->cell->cell); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Village:</strong><?php echo e($client->address->village->village); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php elseif($regMeter): ?>
                                        <div id="" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Main Meter Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="-mt-6">
                                                    <div class="grid grid-cols-12 gap-6 mt-5">
                                                        
                                                        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
                                                            <div class="flex mt-5 sm:mt-0 ml-2">
                                                            </div>
                                                            <div class="hidden md:block mx-auto text-gray-600">
                                                                
                                                            </div>
                                                            <div class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0">
                                                                <div class="w-56 relative text-gray-700 dark:text-gray-300">
                                                                    <input wire:model.debounce.100ms="search" type="text" class="form-control w-56 h-8 box pr-10 placeholder-theme-13 border-blue-200" placeholder="Search...">
                                                                    <i class="w-4 h-4 absolute my-auto inset-y-0 mr-3 right-0" data-feather="search"></i>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
                                                            <?php if(auth()->user()->role->name != 'agent'): ?>
                                                            <table class="table table-report -mt-2 table-responsive w-full">
                                                            <?php else: ?>
                                                            <table class="table table-report -mt-2 table-responsive w-full" style="width: 120%">
                                                            <?php endif; ?>
                                                                <thead>
                                                                    <tr>
                                                                        <th class="whitespace-nowrap">S/N</th>
                                                                        <th class="whitespace-nowrap">Meter Number</th>
                                                                        <th class="text-center whitespace-nowrap">ACTIONS</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>

                                                                    <?php $__empty_1 = true; $__currentLoopData = $meters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                        
                                                                        <tr class="intro-x">
                                                                            <td>
                                                                                <?php echo e($i++); ?>

                                                                            </td>
                                                                            <td>
                                                                                <div class="btn-rounded pl-2 pr-2 btn-primary-soft " wire:click="showLocation(<?php echo e($item->id); ?>)"><?php echo e($item->reg_meter_number); ?></div>
                                                                            </td>
                                                                            <td class="table-report__action w-auto">
                                                                                <div class="flex justify-center items-center">
                                                                                    <button type="button" class="flex items-center btn btn-rounded btn-primary-soft  w-25 mr-3 -mt-1 h-6" wire:click="showElectrix(<?php echo e($item->id); ?>,<?php echo e($client->id); ?>)">
                                                                                        <i class="far fa-eye w-4 h-3 mr-1 mt-1"></i>
                                                                                        Meters
                                                                                    </button>
                                                                                    <?php if(auth()->user()->role->name == 'super_admin' || auth()->user()->role->name == 'admin'): ?>
                                                                                        <?php if($item->meter_status == 'Active'): ?>
                                                                                        <button type="button" class="flex items-center btn btn-rounded btn-danger-soft w-25 mr-3 -mt-1 h-6" wire:click="deactivateMeter(<?php echo e($item->id); ?>,<?php echo e($client->id); ?>)">
                                                                                            <i class="far fa-edit w-4 h-3 mr-1 mt-1"></i>
                                                                                            Deactivate
                                                                                        </button>
                                                                                        <?php else: ?>
                                                                                        <button type="button" class="flex items-center btn btn-rounded btn-success-soft w-25 mr-3 -mt-1 h-6" wire:click="activateMeter(<?php echo e($item->id); ?>,<?php echo e($client->id); ?>)">
                                                                                            <i class="far fa-edit w-4 h-3 mr-1 mt-1"></i>
                                                                                            Activate
                                                                                        </button>
                                                                                        <?php endif; ?>
                                                                                    <?php endif; ?>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                        <tr class="intro-x">
                                                                            <td colspan="7" class="text-center">
                                                                                No record found!
                                                                            </td>
                                                                        </tr>
                                                                    <?php endif; ?>
                                                                    </tbody>
                                                            </table>
                                                        </div>
                                                        <!-- END: Data List -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php elseif($showElectrix): ?>
                                        <div id="" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Main Meter N<sup>o</sup>: 
                                                <span wire:click="showLocation(<?php echo e($mainMeter->id); ?>)"><span class="text-gray-700"><?php echo e($mainMeter->reg_meter_number); ?></span></span> 
                                                <span wire:click="showElectrix(<?php echo e($mainMeter->id); ?>, <?php echo e($mainMeter->client_id); ?>)" class="flex justify-end items-end"><i class="fas fa-redo w-4 h-4 -mt-4 mr-2"></i></span> 
                                            </div>
                                            <?php if(auth()->user()->role->name != 'client'): ?>
                                                <div class="flex flex-wrap justify-end items-end mt-2">
                                                    <button wire:click="addElectrix(<?php echo e($mainMeter->id); ?>)" type="button" class="p-1 pr-2 pl-2 btn btn-rounded btn-primary-soft" style="border: 1px solid rgb(151, 151, 233)">ADD Electrix Meter</button>
                                                </div>
                                            <?php endif; ?>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="-mt-6">
                                                    <div class="grid grid-cols-12 gap-6 mt-5">
                                                        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
                                                            <?php if(auth()->user()->role->name != 'agent'): ?>
                                                            <table class="table table-report -mt-2 table-responsive w-full">
                                                            <?php else: ?>
                                                            <table class="table table-report -mt-2 table-responsive w-full" style="width: 150%">
                                                            <?php endif; ?>
                                                                <thead>
                                                                    <tr>
                                                                        <th class="whitespace-nowrap">S/N</th>
                                                                        <th class="whitespace-nowrap">Electrix Meter N<sup>o</sup></th>
                                                                        <th class="whitespace-nowrap">Status</th>
                                                                        <?php if(auth()->user()->role->name == 'super_admin' || auth()->user()->role->name == 'admin'): ?>
                                                                        <th class="text-center whitespace-nowrap">ACTIONS</th>
                                                                        <?php endif; ?>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>

                                                                    <?php $__empty_1 = true; $__currentLoopData = $electrixMeter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                        
                                                                        <tr class="intro-x">
                                                                            <td>
                                                                                <?php echo e($i++); ?>

                                                                            </td>
                                                                            <td>
                                                                                <span class="btn-rounded btn-primary-soft pr-2 pl-2" wire:click="showLocation(<?php echo e($mainMeter->id); ?>)"><?php echo e($item->electrix_meter_number); ?></span>
                                                                            </td>
                                                                            <td>
                                                                                <?php if($item->meter_status == 'Active'): ?>
                                                                                <span class="rounded-lg pr-1 pl-1 btn-success-soft"><?php echo e($item->meter_status); ?></span>
                                                                                <?php else: ?>
                                                                                <span class="rounded-lg pr-1 pl-1  btn-danger-soft"><?php echo e($item->meter_status); ?></span>
                                                                                <?php endif; ?>
                                                                            </td>
                                                                            <?php if(auth()->user()->role->name == 'super_admin' || auth()->user()->role->name == 'admin'): ?>
                                                                                <td class="table-report__action w-auto text-center">
                                                                                    <div class="flex justify-center items-center">
                                                                                        <?php if($item->meter_status == 'Active'): ?>
                                                                                        <button type="button" class="flex items-center btn btn-rounded btn-danger-soft w-25 mr-3 -mt-1 h-6" wire:click="electrixDeactivate(<?php echo e($item->id); ?>,<?php echo e($client->id); ?>)">
                                                                                            <i class="far fa-edit w-4 h-3 mr-1 mt-1"></i>
                                                                                            Deactivate
                                                                                        </button>
                                                                                        <?php else: ?>
                                                                                        <button type="button" class="flex items-center btn btn-rounded btn-success-soft w-25 mr-3 -mt-1 h-6" wire:click="electrixActivate(<?php echo e($item->id); ?>,<?php echo e($client->id); ?>)">
                                                                                            <i class="far fa-edit w-4 h-3 mr-1 mt-1"></i>
                                                                                            Activate
                                                                                        </button>
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                </td>
                                                                            <?php endif; ?>
                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                        <tr class="intro-x">
                                                                            <td colspan="7" class="text-center">
                                                                                No record found!
                                                                            </td>
                                                                        </tr>
                                                                    <?php endif; ?>
                                                                    </tbody>
                                                            </table>
                                                        </div>
                                                        <!-- END: Data List -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php elseif($meterLocation): ?>
                                        <div id="" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">
                                                <span>Meter N<sup>o</sup>:</span>
                                                <span class="btn-primary-soft pr-2 pl-2 rounded-lg"><?php echo e($meter->reg_meter_number); ?></span>
                                                Location
                                            </div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="truncate sm:whitespace-normal flex items-center"> 
                                                    <i class="fa-solid fa-bolt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Meter Type:</strong><?php echo e($meter->meter_type); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex items-center mt-2"> 
                                                    <i class="fas fa-map-marked-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Land UPI:</strong><?php echo e($meter->land_upi); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex items-center mt-2"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Province:</strong><?php echo e($meter->province->province); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">District:</strong><?php echo e($meter->district->district); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Sector:</strong><?php echo e($meter->sector->sector); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Cell:</strong><?php echo e($meter->cell->cell); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Village:</strong><?php echo e($meter->village->village); ?></span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Street Address:</strong><?php echo e($meter->meter_street_address); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="nav nav-tabs flex-col sm:flex-row justify-center lg:justify-start" role="tablist"> 
                                    <button wire:click="personalInfo" type="button" id="dashboard-tab" data-toggle="tab" data-target="#dashboard" class="py-4 sm:mr-8 <?php if($personalInfo): ?> active <?php endif; ?>" role="tab" aria-controls="dashboard" aria-selected="true">Personal Info</button> 
                                    <button wire:click="contactInfo" type="button" id="account-and-profile-tab" data-toggle="tab" data-target="#account-and-profile" class="py-4 sm:mr-8 <?php if($contactInfo): ?> active <?php endif; ?>" role="tab" aria-selected="false">Contact Info</button> 
                                    <button wire:click="addressInfo" type="button" id="activities-tab" data-toggle="tab" data-target="#activities" class="py-4 sm:mr-8 <?php if($addressInfo): ?> active <?php endif; ?>" role="tab" aria-selected="false">Address Info</button> 
                                    <button wire:click="RegMeterInfo" type="button" id="activities-tab" data-toggle="tab" data-target="#activities" class="py-4 sm:mr-8 <?php if($regMeter || $showElectrix): ?> active <?php endif; ?>" role="tab" aria-selected="false">Meters Info</button> 
                                    <?php if($meterLocation): ?>
                                    <button type="button"  class="py-4 sm:mr-8 <?php if($meterLocation): ?> active <?php endif; ?>" role="tab" aria-selected="false">Meters Location</button> 
                                    <?php endif; ?>
                                    <div class="mt-3 flex justify-center" id="hide">
                                        <div class="preview">
                                            <?php if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin'): ?>
                                                <?php if($client->account_status == 'Inactive'): ?>
                                                <button wire:click="activate(<?php echo e($client->id); ?>)" type="button" style="background-color: green; hover:border: 1px solid white" class="btn btn-rounded-success w-24 mr-1 mb-2">Activate</button>
                                                <?php elseif($client->account_status == 'Active'): ?>
                                                <button wire:click="suspend(<?php echo e($client->id); ?>)" type="button" style="background-color: red; hover:border: 1px solid white" class="btn btn-rounded-danger w-24 mr-1 mb-2">Suspend</button>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if(auth()->user()->role->name != 'client'): ?>
                                                <button wire:click="addMeter(<?php echo e($client->id); ?>)" type="button" style="background-color: rgb(17, 17, 134)" class="btn btn-rounded-primary w-54 mr-1 mb-2"><i class="fas fa-plus mr-2 w-4 h-3"></i> ADD Meter</button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
        </div>
    </div>    
</div>
<?php elseif($addMeter): ?>
    <?php echo $__env->make('client.add-meter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php elseif($addElectrix): ?>
    <?php echo $__env->make('client.add-meter-electrix', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php endif; ?><?php /**PATH /home/nahimana/Documents/workspace/electrix-meter/resources/views/livewire/client/client-show.blade.php ENDPATH**/ ?>