<?php $__env->startSection('title'); ?>
    Register Agent | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-agent'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Register Agent
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('agent.agent-create')->html();
} elseif ($_instance->childHasBeenRendered('860ThcR')) {
    $componentId = $_instance->getRenderedChildComponentId('860ThcR');
    $componentTag = $_instance->getRenderedChildComponentTagName('860ThcR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('860ThcR');
} else {
    $response = \Livewire\Livewire::mount('agent.agent-create');
    $html = $response->html();
    $_instance->logRenderedChild('860ThcR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahimana/Documents/workspace/electrix-meter/resources/views/agent/create.blade.php ENDPATH**/ ?>