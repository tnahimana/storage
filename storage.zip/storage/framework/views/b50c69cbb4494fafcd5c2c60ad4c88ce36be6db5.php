<?php $__env->startSection('title'); ?>
    Agents | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-agent'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Agents
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    agents
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('agent.agent-index')->html();
} elseif ($_instance->childHasBeenRendered('MqKiwjI')) {
    $componentId = $_instance->getRenderedChildComponentId('MqKiwjI');
    $componentTag = $_instance->getRenderedChildComponentTagName('MqKiwjI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MqKiwjI');
} else {
    $response = \Livewire\Livewire::mount('agent.agent-index');
    $html = $response->html();
    $_instance->logRenderedChild('MqKiwjI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/agent/index.blade.php ENDPATH**/ ?>