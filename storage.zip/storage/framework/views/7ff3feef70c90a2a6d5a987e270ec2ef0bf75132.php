<?php $__env->startSection('title'); ?>
    Release Update | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-shortcode'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Release Update
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('shortcode.shortcode-create')->html();
} elseif ($_instance->childHasBeenRendered('7YZ3P6T')) {
    $componentId = $_instance->getRenderedChildComponentId('7YZ3P6T');
    $componentTag = $_instance->getRenderedChildComponentTagName('7YZ3P6T');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7YZ3P6T');
} else {
    $response = \Livewire\Livewire::mount('shortcode.shortcode-create');
    $html = $response->html();
    $_instance->logRenderedChild('7YZ3P6T', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/shortcode/create.blade.php ENDPATH**/ ?>