<?php $__env->startSection('title'); ?>
    Meter Actions | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-meters'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Meter Actions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    meters
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('meter.meter-actions')->html();
} elseif ($_instance->childHasBeenRendered('GLKh0fu')) {
    $componentId = $_instance->getRenderedChildComponentId('GLKh0fu');
    $componentTag = $_instance->getRenderedChildComponentTagName('GLKh0fu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GLKh0fu');
} else {
    $response = \Livewire\Livewire::mount('meter.meter-actions');
    $html = $response->html();
    $_instance->logRenderedChild('GLKh0fu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/meter/index.blade.php ENDPATH**/ ?>