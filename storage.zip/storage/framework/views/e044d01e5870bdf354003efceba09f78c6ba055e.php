<?php if($paginator->hasPages()): ?>
    <div class="flex items-end my-2">
        
        <?php if( ! $paginator->onFirstPage()): ?>
            
            <a
            class="mx-1 px-4 py-2 bg-blue-900 border-2 border-blue-900 text-white font-bold text-center hover:bg-blue-400 hover:border-blue-400 rounded-lg  cursor-pointer"
            wire:click="gotoPage(1)"
            >
            <<
            </a>
            <?php if($paginator->currentPage() > 2): ?>
            
            <a
                class="mx-1 px-4 py-2 bg-blue-900 border-2 border-blue-900 text-white font-bold text-center hover:bg-blue-400 hover:border-blue-400 rounded-lg  cursor-pointer"
                wire:click="previousPage"
            >
            <
            </a>
            <?php endif; ?>
        <?php endif; ?>

        <!-- Pagination Elements -->
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Array Of Links -->
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--  Use three dots when current page is greater than 3.  -->
                    <?php if($paginator->currentPage() > 3 && $page === 2): ?>
                        <div class="text-blue-800 mx-1">
                            <span class="font-bold">.</span>
                            <span class="font-bold">.</span>
                            <span class="font-bold">.</span>
                        </div>
                    <?php endif; ?>

                    <!--  Show active page two pages before and after it.  -->
                    <?php if($page == $paginator->currentPage()): ?>
                        <span class="mx-1 px-4 py-2 border-2 border-blue-400 bg-blue-400 text-white font-bold text-center hover:bg-blue-800 hover:border-blue-800 rounded-lg  cursor-pointer"><?php echo e($page); ?></span>
                    <?php elseif($page === $paginator->currentPage() + 1 || $page === $paginator->currentPage() + 2 || $page === $paginator->currentPage() - 1 || $page === $paginator->currentPage() - 2): ?>
                        <a class="mx-1 px-4 py-2 border-2 border-blue-900 text-blue-900 font-bold text-center hover:text-blue-400 rounded-lg  cursor-pointer" wire:click="gotoPage(<?php echo e($page); ?>)"><?php echo e($page); ?></a>
                    <?php endif; ?>

                    <!--  Use three dots when current page is away from end.  -->
                    <?php if($paginator->currentPage() < $paginator->lastPage() - 2  && $page === $paginator->lastPage() - 1): ?>
                        <div class="text-blue-800 mx-1">
                            <span class="font-bold">.</span>
                            <span class="font-bold">.</span>
                            <span class="font-bold">.</span>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
        <?php if($paginator->hasMorePages()): ?>
            <?php if($paginator->lastPage() - $paginator->currentPage() >= 2): ?>
                <a class="mx-1 px-4 py-2 bg-blue-900 border-2 border-blue-900 text-white font-bold text-center hover:bg-blue-400 hover:border-blue-400 rounded-lg  cursor-pointer"
                wire:click="nextPage"
                rel="next">
                >
                </a>
            <?php endif; ?>
            <a
                class="mx-1 px-4 py-2 bg-blue-900 border-2 border-blue-900 text-white font-bold text-center hover:bg-blue-400 hover:border-blue-400 rounded-lg  cursor-pointer"
                wire:click="gotoPage(<?php echo e($paginator->lastPage()); ?>)"
            >
            >>
            </a>
        <?php endif; ?>
    </div>
<?php endif; ?><?php /**PATH /home/nahimana/Documents/workspace/electrix-meter/resources/views/layout/components/custom-pagination.blade.php ENDPATH**/ ?>