
<div id="loaderIcon" class="flex justify-center items-center space-x-2">
  <div class="spinner-grow inline-block w-8 h-8 bg-current rounded-full opacity-0 text-blue-600" role="status">
    <span class="visually-hidden">Loading...</span>
  </div>
  <div class="
      spinner-grow inline-block w-8 h-8 bg-current rounded-full opacity-0
        text-purple-500
      " role="status">
    <span class="visually-hidden">Loading...</span>
  </div>
  <div class="
      spinner-grow inline-block w-8 h-8 bg-current rounded-full opacity-0
        text-green-500
      " role="status">
    <span class="visually-hidden">Loading...</span>
  </div>
  <div class="spinner-grow inline-block w-8 h-8 bg-current rounded-full opacity-0 text-red-500" role="status">
    <span class="visually-hidden">Loading...</span>
  </div>
  <div class="
      spinner-grow inline-block w-8 h-8 bg-current rounded-full opacity-0
        text-yellow-500
      " role="status">
    <span class="visually-hidden">Loading...</span>
  </div>
  <div class="spinner-grow inline-block w-8 h-8 bg-current rounded-full opacity-0 text-blue-300" role="status">
    <span class="visually-hidden">Loading...</span>
  </div>
  <div class="spinner-grow inline-block w-8 h-8 bg-current rounded-full opacity-0 text-gray-300" role="status">
    <span class="visually-hidden">Loading...</span>
  </div>
</div>



<script>
function callAjax(e){
    $('#loaderIcon').show();
    $.ajax({
        type: "GET",
        url: 'https://api.joind.in/v2.1/talks/10889',
        data: {
            format: 'json'
        },
        success: function(response){
           console.log(response);
        },
        complete: function(){
            $('#loaderIcon').hide();
        }
    });
}
</script><?php /**PATH /home/nahimana/Documents/workspace/electrix-meter/resources/views/layout/components/loading.blade.php ENDPATH**/ ?>